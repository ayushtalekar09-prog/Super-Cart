import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CartProvider, useCart } from './context/CartContext';
import { ThemeProvider } from './context/ThemeContext';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { WishlistProvider } from './context/WishlistContext';
import { SplashAnimation } from './components/SplashAnimation';
import { Navbar } from './components/Navbar';
import { MobileBottomNav } from './components/MobileBottomNav';
import { StoreHome } from './components/StoreHome';
import { CategoriesView } from './components/CategoriesView';
import { WishlistView } from './components/WishlistView';
import { ProductQuickView } from './components/ProductQuickView';
import { CartDrawer } from './components/CartDrawer';
import { LocationModal } from './components/LocationModal';
import { OrderTrackingView } from './components/OrderTrackingView';
import { PastOrdersView } from './components/PastOrdersView';
import { InvoiceModal } from './components/InvoiceModal';
import { AuthModal } from './components/AuthModal';
import { ProfileView } from './components/ProfileView';
import { SettingsView } from './components/SettingsView';
import { BillsInvoicesView } from './components/BillsInvoicesView';
import { AdminDashboard } from './components/AdminDashboard';
import { OrderSuccessModal } from './components/OrderSuccessModal';
import { RunningFooter } from './components/RunningFooter';
import { AppView } from './components/SettingsDrawer';
import { ProtectedRoute } from './components/ProtectedRoute';
import { LoginPage } from './components/LoginPage';
import { supabase } from './supabaseClient.js';
import { Product, Order } from './types';
import { subscribeToSupabaseProducts as subscribeToProducts, createSupabaseOrder } from './lib/supabase';
import confetti from 'canvas-confetti';

function SuperCartContent() {
  const { user, userProfile } = useAuth();
  const { setIsCartOpen, clearCart } = useCart();
  const [splashFinished, setSplashFinished] = useState(false);
  const [products, setProducts] = useState<Product[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [currentView, setCurrentView] = useState<AppView>('home');
  const [searchQuery, setSearchQuery] = useState('');

  // Handle explicit URL routing for /login and /signup
  const pathname = typeof window !== 'undefined' ? window.location.pathname.toLowerCase() : '';
  if (pathname === '/login' || pathname === '/signin') {
    return <LoginPage initialMode="signin" />;
  }
  if (pathname === '/signup') {
    return <LoginPage initialMode="signup" />;
  }

  // Modals & Active View states
  const [locationModalOpen, setLocationModalOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [trackingOrder, setTrackingOrder] = useState<Order | null>(null);
  const [invoiceOrder, setInvoiceOrder] = useState<Order | null>(null);
  const [successOrder, setSuccessOrder] = useState<Order | null>(null);

  // Check URL pathname on initial mount for direct access to private pages
  useEffect(() => {
    const path = window.location.pathname.toLowerCase();
    const privateRoutes: Record<string, AppView> = {
      '/admin': 'admin',
      '/dashboard': 'admin',
      '/profile': 'profile',
      '/orders': 'orders',
      '/bills': 'bills',
      '/settings': 'settings',
    };

    if (privateRoutes[path]) {
      supabase.auth.getSession().then(({ data }) => {
        if (!data?.session) {
          window.location.href = '/login';
        } else {
          setCurrentView(privateRoutes[path]);
        }
      });
    }
  }, []);

  // Check for Razorpay payment callback redirect (e.g. ?payment_status=success or ?payment_status=failed)
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const urlParams = new URLSearchParams(window.location.search);
    const paymentStatus = urlParams.get('payment_status');

    if (paymentStatus === 'success') {
      const paymentId = urlParams.get('payment_id');
      const orderId = urlParams.get('order_id');
      const pendingRaw = localStorage.getItem('supercart_pending_order');

      if (pendingRaw) {
        try {
          const pendingOrder = JSON.parse(pendingRaw);
          const fullOrderPayload = {
            ...pendingOrder,
            razorpayPaymentId: paymentId || undefined,
            razorpayOrderId: orderId || undefined,
          };

          createSupabaseOrder(fullOrderPayload).then((createdId) => {
            const finalOrder: Order = {
              ...fullOrderPayload,
              id: createdId,
              createdAt: new Date().toISOString(),
              estimatedDeliveryTime: new Date(Date.now() + 20 * 60 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              driverName: 'Ramesh Patil',
              driverPhone: '+91 98230 45678',
              driverVehicle: 'SuperCart Electric Express (MH-12-EK-4040)',
            };
            setSuccessOrder(finalOrder);
            localStorage.removeItem('supercart_pending_order');
            clearCart();
            setIsCartOpen(false);
            try {
              confetti({ particleCount: 120, spread: 80, origin: { y: 0.6 } });
            } catch (e) {}
          });
        } catch (err) {
          console.error('Error handling payment callback order:', err);
        }
      }
      // Remove query parameters from URL cleanly without reloading
      window.history.replaceState({}, document.title, window.location.pathname);
    } else if (paymentStatus === 'failed') {
      const errorMsg = urlParams.get('error') || 'Payment could not be completed';
      console.warn('Payment failed callback:', errorMsg);
      localStorage.removeItem('supercart_pending_order');
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);

  // Protected navigation handler
  const handleNavigateView = async (view: AppView) => {
    const privateViews: AppView[] = ['admin', 'profile', 'orders', 'bills', 'settings'];
    if (privateViews.includes(view)) {
      const { data } = await supabase.auth.getSession();
      if (!data?.session) {
        window.location.href = '/login';
        return;
      }
    }
    setTrackingOrder(null);
    setCurrentView(view);
  };

  // Subscribe to live products
  useEffect(() => {
    const unsubscribe = subscribeToProducts(
      (items) => {
        setProducts(items);
        setLoadingProducts(false);
      },
      (err) => {
        console.warn('Products load note:', err);
        setLoadingProducts(false);
      }
    );
    return () => unsubscribe();
  }, []);

  // Automatic view routing based on role when admin is selected
  useEffect(() => {
    if (currentView === 'admin' && userProfile?.role !== 'admin') {
      setCurrentView('home');
    }
  }, [userProfile, currentView]);

  return (
    <div className="min-h-screen flex flex-col bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 font-sans transition-colors overflow-x-hidden w-full">
      {/* 1. Mobile & Initial Splash Animation */}
      {!splashFinished && (
        <SplashAnimation onComplete={() => setSplashFinished(true)} />
      )}

      {/* 2. Global Modals */}
      <LocationModal
        isOpen={locationModalOpen}
        onClose={() => setLocationModalOpen(false)}
      />

      <ProductQuickView
        product={quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
      />

      <CartDrawer
        onOpenLocationModal={() => setLocationModalOpen(true)}
        onOrderSuccess={(order) => {
          setSuccessOrder(order);
        }}
      />

      <OrderSuccessModal
        order={successOrder}
        onClose={() => setSuccessOrder(null)}
        onTrackOrder={(ord) => {
          setTrackingOrder(ord);
          setCurrentView('orders');
        }}
        onViewInvoice={(ord) => {
          setInvoiceOrder(ord);
        }}
      />

      <InvoiceModal
        order={invoiceOrder}
        onClose={() => setInvoiceOrder(null)}
      />

      <AuthModal />

      {/* 3. Global Sticky Navigation */}
      <Navbar
        currentView={currentView}
        setCurrentView={handleNavigateView}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onOpenLocationModal={() => setLocationModalOpen(true)}
      />

      {/* 4. Main Body Content Switcher */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 pt-3 sm:pt-6 pb-20 sm:pb-12">
        {/* Admin Dashboard */}
        {currentView === 'admin' && userProfile?.role === 'admin' ? (
          <ProtectedRoute>
            <AdminDashboard />
          </ProtectedRoute>
        ) : trackingOrder ? (
          <OrderTrackingView
            order={trackingOrder}
            onBack={() => setTrackingOrder(null)}
            onViewInvoice={(ord) => setInvoiceOrder(ord)}
          />
        ) : currentView === 'categories' ? (
          <CategoriesView
            products={products}
            onQuickView={(p) => setQuickViewProduct(p)}
          />
        ) : currentView === 'wishlist' ? (
          <WishlistView
            onQuickView={(p) => setQuickViewProduct(p)}
            onContinueShopping={() => setCurrentView('home')}
          />
        ) : currentView === 'orders' ? (
          <ProtectedRoute>
            <PastOrdersView
              onTrackOrder={(ord) => setTrackingOrder(ord)}
              onViewInvoice={(ord) => setInvoiceOrder(ord)}
              onContinueShopping={() => setCurrentView('home')}
            />
          </ProtectedRoute>
        ) : currentView === 'profile' ? (
          <ProtectedRoute>
            <ProfileView
              onOpenLocationModal={() => setLocationModalOpen(true)}
              onNavigateOrders={() => handleNavigateView('orders')}
              onNavigateHome={() => setCurrentView('home')}
            />
          </ProtectedRoute>
        ) : currentView === 'bills' ? (
          <ProtectedRoute>
            <BillsInvoicesView
              onBackToHome={() => setCurrentView('home')}
            />
          </ProtectedRoute>
        ) : currentView === 'settings' ? (
          <ProtectedRoute>
            <SettingsView
              onTrackOrder={(ord) => {
                setTrackingOrder(ord);
                handleNavigateView('orders');
              }}
            />
          </ProtectedRoute>
        ) : (
          <StoreHome
            products={products}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            onQuickView={(p) => setQuickViewProduct(p)}
          />
        )}
      </main>

      {/* 5. Mobile Thumb Bottom Navigation */}
      <MobileBottomNav
        currentView={currentView}
        setCurrentView={handleNavigateView}
        onOpenLocationModal={() => setLocationModalOpen(true)}
      />

      {/* 6. Running Marquee Footer with Quality Promises & Indian Sourcing */}
      <RunningFooter />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <AuthProvider>
          <WishlistProvider>
            <CartProvider>
              <SuperCartContent />
            </CartProvider>
          </WishlistProvider>
        </AuthProvider>
      </LanguageProvider>
    </ThemeProvider>
  );
}
