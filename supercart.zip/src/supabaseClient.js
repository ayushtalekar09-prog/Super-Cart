import { createClient } from '@supabase/supabase-js';

// ==============================================================================
// SUPABASE CONFIGURATION
// Replace or paste your Supabase Project URL and Public API Key below:
// ==============================================================================
const SUPABASE_URL = "https://wavkucsbhhcgnypntglt.supabase.co";
const SUPABASE_PUBLIC_KEY = "sb_publishable_EoL2Hn1HlRRhZDNBzjRGEg_VQNCqsKP";

// Export Supabase client singleton
export const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLIC_KEY);
