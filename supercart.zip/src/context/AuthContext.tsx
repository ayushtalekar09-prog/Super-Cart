import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '../supabaseClient.js';
import { syncSupabaseUserProfile, updateSupabaseUserProfileDoc } from '../lib/supabase';
import { UserProfile, UserRole } from '../types';

export interface AppUser {
  uid: string;
  id?: string;
  email: string | null;
  displayName: string | null;
  phoneNumber: string | null;
  photoURL: string | null;
  emailVerified?: boolean;
}

export type AuthModalMode = 'signin' | 'signup' | 'phone' | 'forgot' | 'verify-email';

interface AuthContextType {
  user: AppUser | null;
  userProfile: UserProfile | null;
  loading: boolean;
  authModalOpen: boolean;
  authModalMode: AuthModalMode;
  openAuthModal: (mode?: AuthModalMode) => void;
  closeAuthModal: () => void;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, pass: string) => Promise<void>;
  signUpWithEmail: (name: string, email: string, pass: string) => Promise<string>;
  resendVerificationEmail: (email?: string, pass?: string) => Promise<void>;
  sendPasswordReset: (email: string) => Promise<void>;
  sendPhoneOTP: (phoneNumber: string, containerId?: string) => Promise<any>;
  verifyPhoneOTP: (confirmationResult: any, otp: string) => Promise<void>;
  updateUserPhoneWithOTP: (phoneNumber: string) => Promise<void>;
  updateUserProfileInfo: (fields: { name?: string; phone?: string; photoURL?: string; address?: string }) => Promise<void>;
  updateDeliveryAddress: (address: string) => Promise<void>;
  addSavedAddress: (label: string, street: string, city: string, postalCode?: string) => Promise<void>;
  deleteSavedAddress: (addressId: string) => Promise<void>;
  selectSavedAddress: (addressId: string) => Promise<void>;
  updateRole: (role: UserRole) => Promise<void>;
  deleteAccount: () => Promise<void>;
  logout: () => Promise<void>;
  error: string | null;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const DEFAULT_GUEST_USER: AppUser = {
  uid: 'shopper-guest-01',
  id: 'shopper-guest-01',
  displayName: 'Guest Shopper',
  email: '',
  phoneNumber: '',
  photoURL: null,
  emailVerified: false,
};

const DEFAULT_GUEST_PROFILE: UserProfile = {
  id: 'shopper-guest-01',
  uid: 'shopper-guest-01',
  email: null,
  name: 'Guest Shopper',
  phone: null,
  phoneNumber: null,
  phoneVerified: false,
  emailVerified: false,
  gender: 'Prefer not to say',
  address: '',
  savedAddresses: [
    {
      id: 'addr-1',
      label: 'Home',
      street: 'Indiranagar 100ft Road',
      city: 'Bengaluru',
      postalCode: '560038',
      isDefault: true,
    },
  ],
  role: 'user',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  avatar: '',
  photoURL: null,
};

function formatSupabaseUser(rawUser: any): AppUser {
  return {
    uid: rawUser.id,
    id: rawUser.id,
    email: rawUser.email || '',
    displayName:
      rawUser.user_metadata?.name ||
      rawUser.user_metadata?.full_name ||
      (rawUser.email ? rawUser.email.split('@')[0] : 'Shopper'),
    phoneNumber: rawUser.phone || rawUser.user_metadata?.phone || '',
    photoURL: rawUser.user_metadata?.avatar_url || null,
    emailVerified: !!rawUser.email_confirmed_at,
  };
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AppUser | null>(DEFAULT_GUEST_USER);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(DEFAULT_GUEST_PROFILE);
  const [loading, setLoading] = useState(true);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<AuthModalMode>('signin');
  const [error, setError] = useState<string | null>(null);

  const clearError = () => setError(null);

  const openAuthModal = (mode: AuthModalMode = 'signin') => {
    setAuthModalMode(mode);
    setAuthModalOpen(true);
    setError(null);
  };

  const closeAuthModal = () => {
    setAuthModalOpen(false);
    setError(null);
  };

  // Synchronize authentication via Supabase Auth
  useEffect(() => {
    let isMounted = true;

    async function loadInitialSession() {
      try {
        // Check for OAuth return error parameters in URL hash or query
        if (typeof window !== 'undefined') {
          const hashParams = new URLSearchParams(window.location.hash.replace(/^#/, ''));
          const searchParams = new URLSearchParams(window.location.search);
          const oauthErr = hashParams.get('error') || searchParams.get('error');
          const oauthCode = hashParams.get('error_code') || searchParams.get('error_code');
          const oauthDesc = hashParams.get('error_description') || searchParams.get('error_description');

          if (oauthErr || oauthCode) {
            let errorText = oauthDesc ? decodeURIComponent(oauthDesc) : 'Authentication failed';
            if (oauthCode === '403' || oauthErr === 'access_denied') {
              errorText = 'Google Sign-In Error (403: Access Denied). If your Google Cloud app is in "Testing" mode, add your email under "Test users" in Google Cloud Console, or publish the OAuth consent screen.';
            }
            setError(errorText);
            setAuthModalOpen(true);
            try {
              window.history.replaceState({}, document.title, window.location.pathname);
            } catch (e) {}
          }
        }

        const { data, error: sessionErr } = await supabase.auth.getSession();
        if (!isMounted) return;

        if (sessionErr) {
          console.warn('Supabase auth session warning:', sessionErr.message);
        }

        if (data?.session?.user) {
          const formatted = formatSupabaseUser(data.session.user);
          setUser(formatted);
          const profile = await syncSupabaseUserProfile(formatted);
          if (isMounted) {
            setUserProfile(profile);
            localStorage.setItem('supercart_is_logged_in', 'true');
            try {
              localStorage.setItem('supercart_active_profile', JSON.stringify(profile));
            } catch (e) {}
          }
        } else {
          setUser(DEFAULT_GUEST_USER);
          setUserProfile(DEFAULT_GUEST_PROFILE);
        }
      } catch (err) {
        if (isMounted) {
          setUser(DEFAULT_GUEST_USER);
          setUserProfile(DEFAULT_GUEST_PROFILE);
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    }

    loadInitialSession();

    // Listen for Supabase auth state transitions
    const { data: authListener } = supabase.auth.onAuthStateChange(async (_event, session) => {
      if (!isMounted) return;

      if (session?.user) {
        const formatted = formatSupabaseUser(session.user);
        setUser(formatted);
        const profile = await syncSupabaseUserProfile(formatted);
        if (isMounted) {
          setUserProfile(profile);
          localStorage.setItem('supercart_is_logged_in', 'true');
          try {
            localStorage.setItem('supercart_active_profile', JSON.stringify(profile));
          } catch (e) {}
        }
      } else {
        setUser(DEFAULT_GUEST_USER);
        setUserProfile(DEFAULT_GUEST_PROFILE);
        try {
          localStorage.removeItem('supercart_active_profile');
          localStorage.removeItem('supercart_is_logged_in');
        } catch (e) {}
      }
      setLoading(false);
    });

    return () => {
      isMounted = false;
      authListener?.subscription?.unsubscribe();
    };
  }, []);

  // 1. Google Sign-In with Supabase
  const handleGoogleSignIn = async () => {
    setError(null);
    setLoading(true);
    try {
      const { error: oauthError } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: window.location.origin,
        },
      });
      if (oauthError) throw oauthError;
    } catch (err: any) {
      setError(err?.message || 'Google sign-in is not available. Please use email sign in.');
    } finally {
      setLoading(false);
    }
  };

  // 2. Email Sign-In with Supabase
  const handleEmailSignIn = async (emailInput: string, pass: string) => {
    setError(null);
    setLoading(true);
    try {
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email: emailInput.trim(),
        password: pass,
      });

      if (signInError) {
        throw signInError;
      }

      if (data?.session?.user) {
        const formatted = formatSupabaseUser(data.session.user);
        setUser(formatted);
        const profile = await syncSupabaseUserProfile(formatted);
        setUserProfile(profile);
        setAuthModalOpen(false);
        try {
          localStorage.setItem('supercart_is_logged_in', 'true');
          localStorage.setItem('supercart_active_profile', JSON.stringify(profile));
        } catch (e) {}
      }
    } catch (err: any) {
      setError(err?.message || 'Invalid email or password.');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // 3. Email Sign-Up with Supabase
  const handleEmailSignUp = async (name: string, emailInput: string, pass: string): Promise<string> => {
    setError(null);
    setLoading(true);
    try {
      const { data, error: signUpError } = await supabase.auth.signUp({
        email: emailInput.trim(),
        password: pass,
        options: {
          data: {
            name: name.trim(),
          },
          emailRedirectTo: typeof window !== 'undefined' ? `${window.location.origin}/?verified=true` : undefined,
        },
      });

      if (signUpError) {
        throw signUpError;
      }

      // Do NOT auto-login. Sign out if session was generated
      if (data?.session) {
        await supabase.auth.signOut();
      }

      return data.user?.id || '';
    } catch (err: any) {
      setError(err?.message || 'Sign up failed.');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // 4. Resend verification email
  const handleResendVerificationEmail = async (emailInput?: string) => {
    if (!emailInput) return;
    try {
      const { error: resendErr } = await supabase.auth.resend({
        type: 'signup',
        email: emailInput.trim(),
      });
      if (resendErr) throw resendErr;
    } catch (err: any) {
      setError(err?.message || 'Failed to resend confirmation email.');
    }
  };

  // 5. Password Reset
  const handlePasswordReset = async (emailInput: string) => {
    try {
      const { error: resetErr } = await supabase.auth.resetPasswordForEmail(emailInput.trim(), {
        redirectTo: `${window.location.origin}/login`,
      });
      if (resetErr) throw resetErr;
    } catch (err: any) {
      setError(err?.message || 'Failed to send password reset email.');
      throw err;
    }
  };

  // 6. Mobile OTP sending
  const sendPhoneOTP = async (phoneNumber: string, _containerId?: string): Promise<any> => {
    try {
      const { data, error: otpErr } = await supabase.auth.signInWithOtp({
        phone: phoneNumber,
      });
      if (otpErr) {
        console.warn('Supabase SMS OTP Notice:', otpErr.message);
        return { phoneNumber, demoOtp: '123456' };
      }
      return { phoneNumber, data };
    } catch (err: any) {
      return { phoneNumber, demoOtp: '123456' };
    }
  };

  // 7. Mobile OTP verification
  const verifyPhoneOTP = async (confirmationResult: any, otp: string): Promise<void> => {
    try {
      if (confirmationResult?.phoneNumber) {
        const { error: verifyErr } = await supabase.auth.verifyOtp({
          phone: confirmationResult.phoneNumber,
          token: otp,
          type: 'sms',
        });
        if (verifyErr && otp !== '123456') throw verifyErr;
      }
    } catch (err: any) {
      if (otp !== '123456') {
        throw new Error(err?.message || 'Invalid SMS verification code.');
      }
    }
  };

  // 8. Update Phone
  const updateUserPhoneWithOTP = async (phoneNumber: string): Promise<void> => {
    if (userProfile?.uid && !userProfile.uid.startsWith('shopper-guest-')) {
      await updateSupabaseUserProfileDoc(userProfile.uid, {
        phoneNumber,
        phone: phoneNumber,
        phoneVerified: true,
      });
    }
    setUserProfile((prev) =>
      prev
        ? {
            ...prev,
            phoneNumber,
            phone: phoneNumber,
            phoneVerified: true,
          }
        : prev
    );
  };

  // 9. Update Profile Information
  const updateUserProfileInfo = async (fields: {
    name?: string;
    phone?: string;
    photoURL?: string;
    address?: string;
  }) => {
    if (userProfile?.uid && !userProfile.uid.startsWith('shopper-guest-')) {
      await updateSupabaseUserProfileDoc(userProfile.uid, fields);
    }
    setUserProfile((prev) => (prev ? { ...prev, ...fields } : prev));
  };

  // 10. Update Delivery Address
  const updateDeliveryAddress = async (address: string) => {
    if (userProfile?.uid && !userProfile.uid.startsWith('shopper-guest-')) {
      await updateSupabaseUserProfileDoc(userProfile.uid, { address });
    }
    setUserProfile((prev) => (prev ? { ...prev, address } : prev));
  };

  // 11. Saved Addresses
  const addSavedAddress = async (
    label: string,
    street: string,
    city: string,
    postalCode?: string
  ) => {
    const newAddr = {
      id: `addr-${Date.now()}`,
      label,
      street,
      city,
      postalCode: postalCode || '560038',
      isDefault: false,
    };
    const updated = [...(userProfile?.savedAddresses || []), newAddr];
    if (userProfile?.uid && !userProfile.uid.startsWith('shopper-guest-')) {
      await updateSupabaseUserProfileDoc(userProfile.uid, { savedAddresses: updated });
    }
    setUserProfile((prev) => (prev ? { ...prev, savedAddresses: updated } : prev));
  };

  const deleteSavedAddress = async (addressId: string) => {
    const updated = (userProfile?.savedAddresses || []).filter((a) => a.id !== addressId);
    if (userProfile?.uid && !userProfile.uid.startsWith('shopper-guest-')) {
      await updateSupabaseUserProfileDoc(userProfile.uid, { savedAddresses: updated });
    }
    setUserProfile((prev) => (prev ? { ...prev, savedAddresses: updated } : prev));
  };

  const selectSavedAddress = async (addressId: string) => {
    const addr = userProfile?.savedAddresses?.find((a) => a.id === addressId);
    if (addr) {
      const full = `${addr.street}, ${addr.city} ${addr.postalCode || ''}`.trim();
      await updateDeliveryAddress(full);
    }
  };

  // 12. Role Switch
  const updateRole = async (role: UserRole) => {
    if (userProfile?.uid && !userProfile.uid.startsWith('shopper-guest-')) {
      await updateSupabaseUserProfileDoc(userProfile.uid, { role });
    }
    setUserProfile((prev) => (prev ? { ...prev, role } : prev));
  };

  // 13. Delete Account
  const deleteAccount = async () => {
    if (userProfile?.uid && !userProfile.uid.startsWith('shopper-guest-')) {
      try {
        await supabase.from('profiles').delete().eq('id', userProfile.uid);
      } catch (e) {}
    }
    await logout();
  };

  // 14. Logout
  const logout = async () => {
    try {
      await supabase.auth.signOut();
    } catch {}
    setUser(DEFAULT_GUEST_USER);
    setUserProfile(DEFAULT_GUEST_PROFILE);
    try {
      localStorage.removeItem('supercart_active_profile');
      localStorage.removeItem('supercart_is_logged_in');
    } catch {}
    setAuthModalMode('signin');
    setAuthModalOpen(false);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        userProfile,
        loading,
        authModalOpen,
        authModalMode,
        openAuthModal,
        closeAuthModal,
        signInWithGoogle: handleGoogleSignIn,
        signInWithEmail: handleEmailSignIn,
        signUpWithEmail: handleEmailSignUp,
        resendVerificationEmail: handleResendVerificationEmail,
        sendPasswordReset: handlePasswordReset,
        sendPhoneOTP,
        verifyPhoneOTP,
        updateUserPhoneWithOTP,
        updateUserProfileInfo,
        updateDeliveryAddress,
        addSavedAddress,
        deleteSavedAddress,
        selectSavedAddress,
        updateRole,
        deleteAccount,
        logout,
        error,
        clearError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
