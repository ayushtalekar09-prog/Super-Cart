// ==============================================================================
// FIREBASE DISCONNECTED
// All Firebase connections and SDK initializations have been completely removed.
// All database, real-time subscriptions, and profile services now run
// exclusively on Supabase PostgreSQL & REST backend.
// ==============================================================================

import {
  supabase,
  SUPABASE_PROJECT_ID,
  SUPABASE_URL,
  SUPABASE_ANON_KEY,
  checkSupabaseHealth,
  seedSupabaseProducts,
  fetchSupabaseProducts,
  subscribeToSupabaseProducts,
  addProductToSupabase,
  updateProductInSupabase,
  deleteProductFromSupabase,
  createSupabaseOrder,
  subscribeToSupabaseUserOrders,
  subscribeToAllSupabaseOrders,
  updateOrderStatusInSupabase,
  syncSupabaseUserProfile,
  updateSupabaseUserProfileDoc,
} from './supabase';

import { Product, Order, OrderStatus, UserProfile } from '../types';

// Re-export all Supabase services
export * from './supabase';

// Forwarding aliases mapping legacy names directly to Supabase services
export const subscribeToProducts = subscribeToSupabaseProducts;
export const addProductToFirestore = addProductToSupabase;
export const updateProductInFirestore = updateProductInSupabase;
export const deleteProductFromFirestore = deleteProductFromSupabase;

export const createOrder = createSupabaseOrder;
export const subscribeToUserOrders = subscribeToSupabaseUserOrders;
export const subscribeToAllOrders = subscribeToAllSupabaseOrders;
export const updateOrderStatusInFirestore = updateOrderStatusInSupabase;

export const syncUserProfile = syncSupabaseUserProfile;
export const updateUserProfileDoc = updateSupabaseUserProfileDoc;

export async function deleteUserAccountDoc(uid: string): Promise<void> {
  if (!uid || uid === 'shopper-guest-01') return;
  try {
    await supabase.from('profiles').delete().eq('id', uid);
  } catch (e) {
    console.warn('Delete profile notice:', e);
  }
}
