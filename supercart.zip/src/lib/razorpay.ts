export interface RazorpayOrderResponse {
  order_id: string;
  amount: number;
  currency: string;
  key_id?: string;
}

export interface RazorpayPaymentSuccessPayload {
  razorpay_payment_id: string;
  razorpay_order_id: string;
  razorpay_signature: string;
}

export interface RazorpayVerificationResponse {
  status: 'success' | 'failed';
  verified?: boolean;
  message?: string;
  payment_id?: string;
  order_id?: string;
  error?: string;
}

export interface CheckoutCustomerInfo {
  name?: string;
  email?: string;
  phone?: string;
  address?: string;
}

/**
 * Loads the official Razorpay Standard Checkout SDK if not already loaded on window.
 */
export const loadRazorpayScript = (): Promise<boolean> => {
  return new Promise((resolve) => {
    if (typeof window === 'undefined') return resolve(false);
    if ((window as any).Razorpay) return resolve(true);

    const existingScript = document.querySelector('script[src="https://checkout.razorpay.com/v1/checkout.js"]');
    if (existingScript) {
      existingScript.addEventListener('load', () => resolve(true));
      existingScript.addEventListener('error', () => resolve(false));
      return;
    }

    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.async = true;
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
};

/**
 * Calls backend to create a Razorpay Order
 * @param amountInRupees Total amount in INR
 */
export async function createBackendOrder(
  amountInRupees: number,
  receipt?: string,
  notes?: Record<string, string>
): Promise<RazorpayOrderResponse> {
  const amountInPaise = Math.round(amountInRupees * 100);

  if (amountInPaise < 100) {
    throw new Error('Order amount must be at least ₹1.00 (100 paise).');
  }

  const response = await fetch('/api/create-order', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      amount: amountInPaise,
      currency: 'INR',
      receipt: receipt || `rcpt_${Date.now()}`,
      notes: notes || {},
    }),
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || 'Failed to create Razorpay order on server.');
  }

  return data;
}

/**
 * Calls backend to verify the cryptographic payment signature
 */
export async function verifyBackendPayment(
  paymentData: RazorpayPaymentSuccessPayload
): Promise<RazorpayVerificationResponse> {
  const response = await fetch('/api/verify-payment', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(paymentData),
  });

  const data = await response.json();

  if (!response.ok || data.status !== 'success') {
    throw new Error(data.error || 'Payment signature verification failed.');
  }

  return data;
}

/**
 * Creates a hosted Razorpay payment link (runs on rzp.io, bypassing origin website whitelisting)
 */
export async function createHostedPaymentLink({
  amountInRupees,
  customer,
  notes,
}: {
  amountInRupees: number;
  customer?: CheckoutCustomerInfo;
  notes?: Record<string, string>;
}): Promise<{ url: string; link_id: string }> {
  const amountInPaise = Math.round(amountInRupees * 100);
  const response = await fetch('/api/create-payment-link', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      amount: amountInPaise,
      currency: 'INR',
      customer,
      notes,
    }),
  });

  const data = await response.json();
  if (!response.ok || !data.url) {
    throw new Error(data.error || 'Failed to create Razorpay payment link');
  }
  return data;
}

/**
 * Checks the latest payment status directly from Razorpay
 */
export async function fetchLatestPaymentStatus() {
  const res = await fetch('/api/latest-payment-status');
  return await res.json();
}

/**
 * Initiates Razorpay Standard Web Checkout Modal
 */
export async function startRazorpayCheckout({
  amountInRupees,
  customer,
  receipt,
  notes,
  onSuccess,
  onError,
  onDismiss,
}: {
  amountInRupees: number;
  customer?: CheckoutCustomerInfo;
  receipt?: string;
  notes?: Record<string, string>;
  onSuccess: (paymentResult: { payment_id: string; order_id: string; signature: string }) => void | Promise<void>;
  onError: (error: Error) => void;
  onDismiss?: () => void;
}): Promise<void> {
  try {
    // 1. Ensure Razorpay script is present
    const isScriptLoaded = await loadRazorpayScript();
    if (!isScriptLoaded || !(window as any).Razorpay) {
      throw new Error('Could not load Razorpay Checkout SDK. Please check your internet connection.');
    }

    // 2. Call backend to create order
    const orderData = await createBackendOrder(amountInRupees, receipt, notes);

    // 3. Obtain Razorpay Key ID (fallback to client env var if needed)
    const keyId =
      orderData.key_id ||
      (import.meta as any).env?.VITE_RAZORPAY_KEY_ID ||
      'rzp_live_TkiftM0MOi4HMe';

    // 4. Configure Razorpay modal options
    const options = {
      key: keyId,
      amount: orderData.amount,
      currency: orderData.currency || 'INR',
      name: 'SuperCart',
      description: '15-Minute Fresh Grocery Delivery',
      image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=256&q=80',
      order_id: orderData.order_id,
      callback_url: `${window.location.origin}/api/payment-callback`,
      redirect: false,
      prefill: {
        name: customer?.name || 'Valued Shopper',
        email: customer?.email || 'shopper@supercart.com',
        contact: customer?.phone?.replace(/\D/g, '').slice(-10) || '9876543210',
      },
      notes: {
        address: customer?.address || 'India',
        ...notes,
      },
      theme: {
        color: '#10B981', // SuperCart Emerald-600
      },
      modal: {
        confirm_close: true,
        ondismiss: () => {
          if (onDismiss) {
            onDismiss();
          }
        },
      },
      handler: async (response: RazorpayPaymentSuccessPayload) => {
        try {
          // 5. Verify payment signature on the backend
          await verifyBackendPayment(response);

          // 6. Notify caller of successful verification
          await onSuccess({
            payment_id: response.razorpay_payment_id,
            order_id: response.razorpay_order_id,
            signature: response.razorpay_signature,
          });
        } catch (verificationError: any) {
          onError(
            new Error(
              verificationError?.message ||
                'Payment signature verification failed. Your order has not been placed.'
            )
          );
        }
      },
    };

    const rzp = new (window as any).Razorpay(options);

    rzp.on('payment.failed', (failedResponse: any) => {
      console.warn('Razorpay payment.failed payload:', failedResponse);
      const desc =
        failedResponse?.error?.description ||
        failedResponse?.error?.reason ||
        'Transaction could not be completed';
      const reason = failedResponse?.error?.reason || '';
      
      if (
        desc.toLowerCase().includes('website does not match') ||
        reason.toLowerCase().includes('risk_check_failed')
      ) {
        onError(
          new Error(
            `Razorpay Security Policy: Live payment blocked because this website domain is not registered in your Razorpay Dashboard (Settings > Website and App Settings). Please whitelist this domain in Razorpay, or test with Cash on Delivery / Razorpay Test credentials.`
          )
        );
      } else {
        onError(new Error(`Payment Failed: ${desc}`));
      }
    });

    rzp.open();
  } catch (err: any) {
    onError(err);
  }
}
