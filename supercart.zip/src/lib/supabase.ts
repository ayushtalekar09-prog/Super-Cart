import { createClient, RealtimeChannel } from '@supabase/supabase-js';
import { Product, Order, OrderStatus, UserProfile } from '../types';
import { INITIAL_PRODUCTS } from '../data/seedProducts';

// Supabase Project Credentials provided by user
export const SUPABASE_PROJECT_ID = 'wavkucsbhhcgnypntglt';
export const SUPABASE_URL = (import.meta as any).env?.VITE_SUPABASE_URL || `https://${SUPABASE_PROJECT_ID}.supabase.co`;
export const SUPABASE_ANON_KEY = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY || 'sb_publishable_EoL2Hn1HlRRhZDNBzjRGEg_VQNCqsKP';

// Singleton Supabase Client
export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
  realtime: {
    params: {
      eventsPerSecond: 10,
    },
  },
});

// Map Supabase DB snake_case record to frontend camelCase Product
export function mapRowToProduct(row: any): Product {
  return {
    id: String(row.id),
    name: row.name || 'Unnamed Product',
    category: row.category || 'General',
    price: Number(row.price) || 0,
    originalPrice: row.original_price != null ? Number(row.original_price) : undefined,
    stock: Number(row.stock) || 0,
    unit: row.unit || 'pack',
    image: row.image || '',
    description: row.description || '',
    rating: row.rating != null ? Number(row.rating) : 4.5,
    reviewCount: row.review_count != null ? Number(row.review_count) : 10,
    badge: row.badge || undefined,
    isFeatured: !!row.is_featured,
    organic: !!row.organic,
    season: row.season || undefined,
    origin: row.origin || undefined,
    ingredients: Array.isArray(row.ingredients) ? row.ingredients : [],
    nutrition: typeof row.nutrition === 'object' && row.nutrition !== null ? row.nutrition : undefined,
  };
}

// Map frontend Product to Supabase row format
export function mapProductToRow(prod: Partial<Product>): Record<string, any> {
  const row: Record<string, any> = {};
  if (prod.id !== undefined) row.id = prod.id;
  if (prod.name !== undefined) row.name = prod.name;
  if (prod.category !== undefined) row.category = prod.category;
  if (prod.price !== undefined) row.price = prod.price;
  if (prod.originalPrice !== undefined) row.original_price = prod.originalPrice;
  if (prod.stock !== undefined) row.stock = prod.stock;
  if (prod.unit !== undefined) row.unit = prod.unit;
  if (prod.image !== undefined) row.image = prod.image;
  if (prod.description !== undefined) row.description = prod.description;
  if (prod.rating !== undefined) row.rating = prod.rating;
  if (prod.reviewCount !== undefined) row.review_count = prod.reviewCount;
  if (prod.badge !== undefined) row.badge = prod.badge;
  if (prod.isFeatured !== undefined) row.is_featured = prod.isFeatured;
  if (prod.organic !== undefined) row.organic = prod.organic;
  if (prod.season !== undefined) row.season = prod.season;
  if (prod.origin !== undefined) row.origin = prod.origin;
  if (prod.ingredients !== undefined) row.ingredients = prod.ingredients;
  if (prod.nutrition !== undefined) row.nutrition = prod.nutrition;
  return row;
}

// Map Supabase DB snake_case record to frontend camelCase Order
export function mapRowToOrder(row: any): Order {
  return {
    id: String(row.id),
    userId: String(row.user_id),
    customerName: row.customer_name || 'Customer',
    customerEmail: row.customer_email || '',
    customerPhone: row.customer_phone || '',
    deliveryAddress: row.delivery_address || '',
    items: Array.isArray(row.items) ? row.items : [],
    subtotal: Number(row.subtotal) || 0,
    discount: Number(row.discount) || 0,
    discountCode: row.discount_code || undefined,
    deliveryFee: Number(row.delivery_fee) || 0,
    tax: Number(row.tax) || 0,
    total: Number(row.total) || 0,
    paymentMethod: row.payment_method || 'UPI / Net Banking',
    status: (row.status as OrderStatus) || 'Placed',
    createdAt: row.created_at || new Date().toISOString(),
    estimatedDeliveryTime: row.estimated_delivery_time,
    driverName: row.driver_name,
    driverPhone: row.driver_phone,
    driverVehicle: row.driver_vehicle,
    notes: row.notes,
    razorpayPaymentId: row.razorpay_payment_id,
    razorpayOrderId: row.razorpay_order_id,
  };
}

// Map frontend Order to Supabase row format
export function mapOrderToRow(order: Partial<Order>): Record<string, any> {
  const row: Record<string, any> = {};
  if (order.id !== undefined) row.id = order.id;
  if (order.userId !== undefined) row.user_id = order.userId;
  if (order.customerName !== undefined) row.customer_name = order.customerName;
  if (order.customerEmail !== undefined) row.customer_email = order.customerEmail;
  if (order.customerPhone !== undefined) row.customer_phone = order.customerPhone;
  if (order.deliveryAddress !== undefined) row.delivery_address = order.deliveryAddress;
  if (order.items !== undefined) row.items = order.items;
  if (order.subtotal !== undefined) row.subtotal = order.subtotal;
  if (order.discount !== undefined) row.discount = order.discount;
  if (order.discountCode !== undefined) row.discount_code = order.discountCode;
  if (order.deliveryFee !== undefined) row.delivery_fee = order.deliveryFee;
  if (order.tax !== undefined) row.tax = order.tax;
  if (order.total !== undefined) row.total = order.total;
  if (order.paymentMethod !== undefined) row.payment_method = order.paymentMethod;
  if (order.status !== undefined) row.status = order.status;
  if (order.createdAt !== undefined) row.created_at = order.createdAt;
  if (order.estimatedDeliveryTime !== undefined) row.estimated_delivery_time = order.estimatedDeliveryTime;
  if (order.driverName !== undefined) row.driver_name = order.driverName;
  if (order.driverPhone !== undefined) row.driver_phone = order.driverPhone;
  if (order.driverVehicle !== undefined) row.driver_vehicle = order.driverVehicle;
  if (order.notes !== undefined) row.notes = order.notes;
  if (order.razorpayPaymentId !== undefined) row.razorpay_payment_id = order.razorpayPaymentId;
  if (order.razorpayOrderId !== undefined) row.razorpay_order_id = order.razorpayOrderId;
  return row;
}

// ----------------------------------------------------
// Health Check / Connection Diagnostic
// ----------------------------------------------------
export interface SupabaseHealth {
  connected: boolean;
  projectUrl: string;
  projectId: string;
  tables: {
    products: boolean;
    orders: boolean;
    profiles: boolean;
  };
  error?: string;
  checkedAt: string;
}

export async function checkSupabaseHealth(): Promise<SupabaseHealth> {
  const result: SupabaseHealth = {
    connected: false,
    projectUrl: SUPABASE_URL,
    projectId: SUPABASE_PROJECT_ID,
    tables: {
      products: false,
      orders: false,
      profiles: false,
    },
    checkedAt: new Date().toISOString(),
  };

  try {
    // 1. Test basic connectivity via auth or simple query
    const { data: authData, error: authError } = await supabase.auth.getSession();
    result.connected = !authError || authError.message.includes('session');

    // 2. Test products table
    const { data: prodData, error: prodError } = await supabase
      .from('products')
      .select('id')
      .limit(1);

    result.tables.products = !prodError;

    // 3. Test orders table
    const { data: orderData, error: orderError } = await supabase
      .from('orders')
      .select('id')
      .limit(1);

    result.tables.orders = !orderError;

    // 4. Test profiles table
    const { data: profData, error: profError } = await supabase
      .from('profiles')
      .select('id')
      .limit(1);

    result.tables.profiles = !profError;

    // Set overall connected status
    result.connected = true;
    return result;
  } catch (err: any) {
    result.error = err?.message || 'Unable to contact Supabase';
    return result;
  }
}

// ----------------------------------------------------
// Products Operations
// ----------------------------------------------------
export async function seedSupabaseProducts(): Promise<{ count: number; error?: string }> {
  try {
    const rows = INITIAL_PRODUCTS.map(p => mapProductToRow(p));
    const { data, error } = await supabase
      .from('products')
      .upsert(rows, { onConflict: 'id' });

    if (error) {
      console.warn('Supabase products upsert notice:', error);
      return { count: 0, error: error.message };
    }
    return { count: INITIAL_PRODUCTS.length };
  } catch (err: any) {
    console.warn('Supabase seed error:', err);
    return { count: 0, error: err?.message || 'Failed to seed products' };
  }
}

export async function fetchSupabaseProducts(): Promise<Product[]> {
  try {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .order('category', { ascending: true });

    if (error) {
      console.warn('Supabase fetchProducts returned error:', error.message);
      return INITIAL_PRODUCTS;
    }

    if (!data || data.length === 0) {
      // If table exists but is empty, try seeding it
      seedSupabaseProducts().catch(() => {});
      return INITIAL_PRODUCTS;
    }

    return data.map(mapRowToProduct);
  } catch (err) {
    console.warn('Supabase fetch exception:', err);
    return INITIAL_PRODUCTS;
  }
}

export function subscribeToSupabaseProducts(
  onSuccess: (products: Product[]) => void,
  onError?: (err: Error) => void
): () => void {
  let isMounted = true;
  let channel: RealtimeChannel | null = null;

  // Initial fetch
  fetchSupabaseProducts()
    .then((items) => {
      if (isMounted) onSuccess(items);
    })
    .catch((err) => {
      if (isMounted) {
        if (onError) onError(err);
        onSuccess(INITIAL_PRODUCTS);
      }
    });

  // Listen to Postgres real-time changes
  try {
    channel = supabase
      .channel('public:products')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'products' },
        async () => {
          if (!isMounted) return;
          const fresh = await fetchSupabaseProducts();
          if (isMounted) onSuccess(fresh);
        }
      )
      .subscribe();
  } catch (e) {
    console.warn('Supabase real-time channel subscription note:', e);
  }

  return () => {
    isMounted = false;
    if (channel) {
      supabase.removeChannel(channel);
    }
  };
}

export async function addProductToSupabase(product: Omit<Product, 'id'>): Promise<string> {
  const newId = `prod_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const row = mapProductToRow({ ...product, id: newId });
  
  try {
    const { error } = await supabase.from('products').insert([row]);
    if (error) {
      console.warn('Supabase insert product warning:', error);
    }
  } catch (e) {
    console.warn('Supabase add product exception:', e);
  }
  return newId;
}

export async function updateProductInSupabase(id: string, updates: Partial<Product>): Promise<void> {
  const rowUpdates = mapProductToRow(updates);
  delete rowUpdates.id; // Don't modify primary key
  try {
    const { error } = await supabase
      .from('products')
      .update(rowUpdates)
      .eq('id', id);

    if (error) {
      console.warn('Supabase update product error:', error.message);
    }
  } catch (e) {
    console.warn('Supabase update product exception:', e);
  }
}

export async function deleteProductFromSupabase(id: string): Promise<void> {
  try {
    const { error } = await supabase
      .from('products')
      .delete()
      .eq('id', id);

    if (error) {
      console.warn('Supabase delete product error:', error.message);
    }
  } catch (e) {
    console.warn('Supabase delete product exception:', e);
  }
}

// ----------------------------------------------------
// Orders Operations
// ----------------------------------------------------
export async function createSupabaseOrder(orderData: Omit<Order, 'id' | 'createdAt'>): Promise<string> {
  const orderId = `SC-${Date.now().toString().slice(-6)}-${Math.floor(100 + Math.random() * 900)}`;
  const createdAt = new Date().toISOString();
  const estimatedDeliveryTime = new Date(Date.now() + 25 * 60 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  
  const fullOrder: Order = {
    ...orderData,
    id: orderId,
    createdAt,
    estimatedDeliveryTime,
    driverName: 'Carlos Ramirez',
    driverPhone: '+91 98765 43210',
    driverVehicle: 'Eco Electric Van (Plate: KA-01-SC-2026)',
  };

  // 1. Cache to local storage immediately
  try {
    const key = `supercart_orders_${orderData.userId}`;
    const existing: Order[] = JSON.parse(localStorage.getItem(key) || '[]');
    existing.unshift(fullOrder);
    localStorage.setItem(key, JSON.stringify(existing));

    const allKey = 'supercart_all_orders';
    const allExisting: Order[] = JSON.parse(localStorage.getItem(allKey) || '[]');
    allExisting.unshift(fullOrder);
    localStorage.setItem(allKey, JSON.stringify(allExisting));
  } catch (e) {}

  // 2. Write to Supabase orders table (with non-blocking timeout)
  try {
    const row = mapOrderToRow(fullOrder);
    await Promise.race([
      supabase.from('orders').insert([row]),
      new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 3000)),
    ]).catch((err) => {
      console.warn('Supabase order insert notice:', err?.message || err);
    });
  } catch (err) {
    console.warn('Supabase order insert exception:', err);
  }

  return orderId;
}

export function subscribeToSupabaseUserOrders(
  userId: string,
  onUpdate: (orders: Order[]) => void
): () => void {
  let isMounted = true;
  let channel: RealtimeChannel | null = null;

  const getLocal = (): Order[] => {
    try {
      const key = `supercart_orders_${userId}`;
      return JSON.parse(localStorage.getItem(key) || '[]');
    } catch {
      return [];
    }
  };

  const fetchOrders = async () => {
    const local = getLocal();
    try {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error || !data) {
        if (isMounted) onUpdate(local);
        return;
      }

      const remoteOrders = data.map(mapRowToOrder);
      // Merge with local orders
      const merged = [...remoteOrders];
      local.forEach(loc => {
        if (!merged.some(m => m.id === loc.id)) {
          merged.push(loc);
        }
      });
      merged.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());

      try {
        localStorage.setItem(`supercart_orders_${userId}`, JSON.stringify(merged));
      } catch {}

      if (isMounted) onUpdate(merged);
    } catch (e) {
      if (isMounted) onUpdate(local);
    }
  };

  // Initial call with local data then remote
  onUpdate(getLocal());
  fetchOrders();

  // Listen to Supabase Realtime changes
  try {
    channel = supabase
      .channel(`public:orders:${userId}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'orders', filter: `user_id=eq.${userId}` },
        () => {
          if (isMounted) fetchOrders();
        }
      )
      .subscribe();
  } catch (e) {
    console.warn('Supabase user orders channel note:', e);
  }

  return () => {
    isMounted = false;
    if (channel) {
      supabase.removeChannel(channel);
    }
  };
}

export function subscribeToAllSupabaseOrders(onUpdate: (orders: Order[]) => void): () => void {
  let isMounted = true;
  let channel: RealtimeChannel | null = null;

  const getLocal = (): Order[] => {
    try {
      return JSON.parse(localStorage.getItem('supercart_all_orders') || '[]');
    } catch {
      return [];
    }
  };

  const fetchAll = async () => {
    const local = getLocal();
    try {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false });

      if (error || !data) {
        if (isMounted) onUpdate(local);
        return;
      }

      const remote = data.map(mapRowToOrder);
      const merged = [...remote];
      local.forEach(loc => {
        if (!merged.some(m => m.id === loc.id)) {
          merged.push(loc);
        }
      });
      merged.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());

      if (isMounted) onUpdate(merged);
    } catch (e) {
      if (isMounted) onUpdate(local);
    }
  };

  onUpdate(getLocal());
  fetchAll();

  try {
    channel = supabase
      .channel('public:all-orders')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'orders' },
        () => {
          if (isMounted) fetchAll();
        }
      )
      .subscribe();
  } catch (e) {
    console.warn('Supabase all-orders channel note:', e);
  }

  return () => {
    isMounted = false;
    if (channel) {
      supabase.removeChannel(channel);
    }
  };
}

export async function updateOrderStatusInSupabase(orderId: string, status: OrderStatus): Promise<void> {
  // Update local storage
  try {
    const allKey = 'supercart_all_orders';
    const allOrders: Order[] = JSON.parse(localStorage.getItem(allKey) || '[]');
    const idx = allOrders.findIndex(o => o.id === orderId);
    if (idx !== -1) {
      allOrders[idx].status = status;
      localStorage.setItem(allKey, JSON.stringify(allOrders));
      const uKey = `supercart_orders_${allOrders[idx].userId}`;
      const userOrders: Order[] = JSON.parse(localStorage.getItem(uKey) || '[]');
      const uIdx = userOrders.findIndex(o => o.id === orderId);
      if (uIdx !== -1) {
        userOrders[uIdx].status = status;
        localStorage.setItem(uKey, JSON.stringify(userOrders));
      }
    }
  } catch (e) {}

  // Update Supabase
  try {
    const { error } = await supabase
      .from('orders')
      .update({ status })
      .eq('id', orderId);

    if (error) {
      console.warn('Supabase update order status error:', error.message);
    }
  } catch (e) {
    console.warn('Supabase update order status exception:', e);
  }
}

// ----------------------------------------------------
// User Profile Operations
// ----------------------------------------------------
export async function syncSupabaseUserProfile(user: any): Promise<UserProfile> {
  const uid = user.uid || user.id || 'shopper-guest-01';
  const defaultProfile: UserProfile = {
    id: uid,
    uid: uid,
    email: user.email || null,
    name: user.displayName || (user.email ? user.email.split('@')[0] : 'SuperCart Shopper'),
    phone: user.phoneNumber || user.phone || null,
    phoneNumber: user.phoneNumber || user.phone || null,
    phoneVerified: !!(user.phoneNumber || user.phone),
    emailVerified: !!user.emailVerified,
    gender: 'Prefer not to say',
    photoURL: user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${uid}`,
    avatar: user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${uid}`,
    address: null,
    savedAddresses: [
      {
        id: 'addr-1',
        label: 'Home',
        street: 'Indiranagar 100ft Road',
        city: 'Bengaluru',
        postalCode: '560038',
        isDefault: true,
      },
    ],
    role: (user.email?.toLowerCase().includes('admin') ? 'admin' : 'user') as 'admin' | 'user',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', uid)
      .single();

    if (!error && data) {
      return {
        id: data.id,
        uid: data.uid || data.id,
        email: data.email || defaultProfile.email,
        name: data.name || defaultProfile.name,
        phone: data.phone || data.phone_number || defaultProfile.phone,
        phoneNumber: data.phone_number || data.phone || defaultProfile.phoneNumber,
        phoneVerified: !!data.phone_verified,
        emailVerified: !!data.email_verified,
        gender: data.gender || 'Prefer not to say',
        photoURL: data.photo_url || data.avatar || defaultProfile.photoURL,
        avatar: data.avatar || data.photo_url || defaultProfile.avatar,
        address: data.address || null,
        savedAddresses: Array.isArray(data.saved_addresses) ? data.saved_addresses : defaultProfile.savedAddresses,
        role: data.role || defaultProfile.role,
        createdAt: data.created_at || defaultProfile.createdAt,
        updatedAt: data.updated_at || defaultProfile.updatedAt,
      };
    } else {
      // Upsert default profile
      await supabase.from('profiles').upsert([
        {
          id: uid,
          uid: uid,
          email: defaultProfile.email,
          name: defaultProfile.name,
          phone: defaultProfile.phone,
          phone_number: defaultProfile.phoneNumber,
          phone_verified: defaultProfile.phoneVerified,
          email_verified: defaultProfile.emailVerified,
          gender: defaultProfile.gender,
          photo_url: defaultProfile.photoURL,
          avatar: defaultProfile.avatar,
          address: defaultProfile.address,
          saved_addresses: defaultProfile.savedAddresses,
          role: defaultProfile.role,
          created_at: defaultProfile.createdAt,
          updated_at: defaultProfile.updatedAt,
        },
      ]);
      return defaultProfile;
    }
  } catch (e) {
    return defaultProfile;
  }
}

export async function updateSupabaseUserProfileDoc(uid: string, fields: Partial<UserProfile> & Record<string, any>): Promise<void> {
  if (!uid || uid === 'shopper-guest-01') return;

  const payload: Record<string, any> = {
    updated_at: new Date().toISOString(),
  };

  if (fields.name !== undefined) payload.name = fields.name;
  if (fields.email !== undefined) payload.email = fields.email;
  if (fields.phone !== undefined) payload.phone = fields.phone;
  if (fields.phoneNumber !== undefined) payload.phone_number = fields.phoneNumber;
  if (fields.phoneVerified !== undefined) payload.phone_verified = fields.phoneVerified;
  if (fields.emailVerified !== undefined) payload.email_verified = fields.emailVerified;
  if (fields.gender !== undefined) payload.gender = fields.gender;
  if (fields.photoURL !== undefined) payload.photo_url = fields.photoURL;
  if (fields.avatar !== undefined) payload.avatar = fields.avatar;
  if (fields.address !== undefined) payload.address = fields.address;
  if (fields.savedAddresses !== undefined) payload.saved_addresses = fields.savedAddresses;
  if (fields.role !== undefined) payload.role = fields.role;

  try {
    const { error } = await supabase
      .from('profiles')
      .update(payload)
      .eq('id', uid);

    if (error) {
      console.warn('Supabase update profile error:', error.message);
    }
  } catch (e) {
    console.warn('Supabase update profile exception:', e);
  }
}
