import React, { useEffect, useState } from 'react';
import { supabase } from '../supabaseClient.js';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

/**
 * Protects private pages using supabase.auth.getSession().
 * If no session exists, the user is immediately redirected to /login.
 */
export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const [loading, setLoading] = useState(true);
  const [hasSession, setHasSession] = useState(false);

  useEffect(() => {
    let isMounted = true;

    async function checkAuthSession() {
      try {
        const { data, error } = await supabase.auth.getSession();
        if (!isMounted) return;

        if (error || !data?.session) {
          // If no session, redirect to /login
          window.location.href = '/login';
          return;
        }

        setHasSession(true);
      } catch (err) {
        if (!isMounted) return;
        window.location.href = '/login';
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    }

    checkAuthSession();

    // Listen for auth session updates in Supabase
    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!isMounted) return;
      if (!session) {
        window.location.href = '/login';
      } else {
        setHasSession(true);
      }
    });

    return () => {
      isMounted = false;
      authListener?.subscription?.unsubscribe();
    };
  }, []);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] p-8 space-y-4">
        <div className="w-10 h-10 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin" />
        <p className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
          Checking security session...
        </p>
      </div>
    );
  }

  if (!hasSession) {
    return null;
  }

  return <>{children}</>;
};
