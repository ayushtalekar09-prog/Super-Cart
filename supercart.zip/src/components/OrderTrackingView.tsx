import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Package, 
  ChefHat, 
  Bike, 
  CheckCircle2, 
  Phone, 
  MapPin, 
  Clock, 
  ArrowLeft, 
  Navigation,
  Sparkles,
  Receipt,
  FileText
} from 'lucide-react';
import { Order, OrderStatus } from '../types';

interface OrderTrackingViewProps {
  order: Order;
  onBack: () => void;
  onViewInvoice: (order: Order) => void;
}

const STATUS_STEPS: { status: OrderStatus; label: string; description: string; icon: any }[] = [
  { status: 'Placed', label: 'Order Placed', description: 'Your order was verified and sent to the local fulfillment center', icon: Package },
  { status: 'Processing', label: 'Packing Fresh Items', description: 'Grocery picker is packing quality items and double-checking freshness', icon: ChefHat },
  { status: 'Out for Delivery', label: 'Out for Delivery', description: 'SuperCart express courier is on the road with your groceries', icon: Bike },
  { status: 'Delivered', label: 'Delivered', description: 'Groceries safely handed over at your doorstep', icon: CheckCircle2 },
];

export const OrderTrackingView: React.FC<OrderTrackingViewProps> = ({
  order,
  onBack,
  onViewInvoice
}) => {
  const [estimatedMinutes, setEstimatedMinutes] = useState(18);

  const getStepIndex = (status: OrderStatus) => {
    switch (status) {
      case 'Placed': return 0;
      case 'Processing': return 1;
      case 'Out for Delivery': return 2;
      case 'Delivered': return 3;
      default: return 0;
    }
  };

  const currentIndex = getStepIndex(order.status);

  // Simulated countdown
  useEffect(() => {
    if (order.status === 'Delivered') {
      setEstimatedMinutes(0);
      return;
    }
    const interval = setInterval(() => {
      setEstimatedMinutes((prev) => (prev > 1 ? prev - 1 : 1));
    }, 60000);
    return () => clearInterval(interval);
  }, [order.status]);

  return (
    <div id="order-tracking-view" className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      {/* Top Breadcrumb Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 transition"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Store / Orders
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onViewInvoice(order)}
            className="px-3.5 py-2 rounded-xl bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-200 font-semibold text-xs shadow-sm hover:bg-zinc-50 dark:hover:bg-zinc-750 transition flex items-center gap-1.5"
          >
            <FileText className="w-4 h-4 text-emerald-600" />
            <span>View Receipt & Invoice</span>
          </button>
        </div>
      </div>

      {/* Main ETA Hero Card */}
      <div className="p-6 md:p-8 rounded-3xl bg-gradient-to-br from-emerald-700 to-emerald-900 text-white shadow-xl shadow-emerald-900/20 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-white/5 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-amber-400 text-emerald-950 mb-3 shadow-sm">
              <Sparkles className="w-3 h-3 mr-1" />
              Live SuperCart Tracking
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              {order.status === 'Delivered'
                ? 'Package Delivered Successfully!'
                : `Estimated Arrival: ~${estimatedMinutes} mins`}
            </h2>
            <p className="text-xs sm:text-sm text-emerald-100/90 mt-1">
              Order #{order.id.slice(0, 10).toUpperCase()} • Express Direct Dispatch
            </p>
          </div>

          {/* Delivery Location badge */}
          <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 max-w-xs text-xs space-y-1">
            <div className="flex items-center gap-1.5 text-emerald-200 font-bold">
              <MapPin className="w-4 h-4 text-amber-300" />
              <span>Destination Address</span>
            </div>
            <p className="text-white line-clamp-2 leading-snug">
              {order.deliveryAddress}
            </p>
          </div>
        </div>
      </div>

      {/* Visual Progress Steps Bar */}
      <div className="p-6 md:p-8 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm">
        <h3 className="text-sm font-bold uppercase tracking-wider text-zinc-400 dark:text-zinc-500 mb-6">
          Delivery Progress Timeline
        </h3>

        <div className="relative">
          {/* Desktop/Tablet Horizontal Steps */}
          <div className="hidden sm:grid grid-cols-4 gap-4 relative">
            {/* Connecting bar */}
            <div className="absolute top-6 left-12 right-12 h-1 bg-zinc-200 dark:bg-zinc-800 -z-0">
              <div
                className="h-full bg-emerald-500 transition-all duration-700 ease-in-out"
                style={{ width: `${(currentIndex / 3) * 100}%` }}
              />
            </div>

            {STATUS_STEPS.map((step, idx) => {
              const isPast = idx < currentIndex;
              const isCurrent = idx === currentIndex;
              const Icon = step.icon;

              return (
                <div key={step.status} className="flex flex-col items-center text-center relative z-10">
                  <div
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-300 shadow-md ${
                      isCurrent
                        ? 'bg-emerald-600 text-white ring-4 ring-emerald-500/20 scale-110 shadow-emerald-500/30'
                        : isPast
                        ? 'bg-emerald-500 text-white'
                        : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-400'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <h4
                    className={`mt-3 text-xs font-bold ${
                      isCurrent || isPast ? 'text-zinc-900 dark:text-white' : 'text-zinc-400'
                    }`}
                  >
                    {step.label}
                  </h4>
                  <p className="mt-1 text-[11px] text-zinc-500 dark:text-zinc-400 leading-tight">
                    {step.description}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Mobile Vertical Steps */}
          <div className="block sm:hidden space-y-6">
            {STATUS_STEPS.map((step, idx) => {
              const isPast = idx < currentIndex;
              const isCurrent = idx === currentIndex;
              const Icon = step.icon;

              return (
                <div key={step.status} className="flex items-start gap-4">
                  <div
                    className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 shadow-sm ${
                      isCurrent
                        ? 'bg-emerald-600 text-white ring-4 ring-emerald-500/20'
                        : isPast
                        ? 'bg-emerald-500 text-white'
                        : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-400'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h4
                      className={`text-xs font-bold ${
                        isCurrent || isPast ? 'text-zinc-900 dark:text-white' : 'text-zinc-400'
                      }`}
                    >
                      {step.label}
                    </h4>
                    <p className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-0.5 leading-snug">
                      {step.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Driver Card & Route Preview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Driver Contact Card */}
        <div className="p-6 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm flex flex-col justify-between">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-zinc-400 dark:text-zinc-500 block mb-3">
              Delivery Associate
            </span>
            <div className="flex items-center gap-3 mb-4">
              <img
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80"
                alt="Driver"
                className="w-12 h-12 rounded-2xl object-cover"
                referrerPolicy="no-referrer"
              />
              <div>
                <h4 className="font-bold text-sm text-zinc-900 dark:text-white">
                  {order.driverName || 'Carlos Ramirez'}
                </h4>
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  {order.driverVehicle || 'SuperCart Eco Electric Van'}
                </p>
              </div>
            </div>
          </div>

          <a
            href={`tel:${order.driverPhone || '+15552348901'}`}
            className="w-full py-2.5 px-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 font-bold text-xs hover:bg-emerald-100 flex items-center justify-center gap-2 transition"
          >
            <Phone className="w-4 h-4" />
            <span>Call Driver ({order.driverPhone || '+1 555-234-8901'})</span>
          </a>
        </div>

        {/* Live Route Graphic Simulation */}
        <div className="md:col-span-2 p-6 rounded-3xl bg-zinc-900 text-white shadow-sm flex flex-col justify-between relative overflow-hidden">
          <div className="relative z-10 flex items-center justify-between mb-4">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
              <Navigation className="w-3.5 h-3.5 animate-pulse" />
              Live Route Radar
            </span>
            <span className="text-[11px] text-zinc-400 font-mono">
              Fulfillment Hub &rarr; Destination
            </span>
          </div>

          {/* Interactive Route SVG simulation */}
          <div className="relative h-28 w-full bg-zinc-950/70 rounded-2xl border border-zinc-800 p-4 flex items-center justify-between overflow-hidden">
            {/* Store Hub */}
            <div className="flex flex-col items-center text-center z-10">
              <div className="w-8 h-8 rounded-xl bg-emerald-600 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-white">
                <Package className="w-4 h-4" />
              </div>
              <span className="text-[10px] text-zinc-400 font-semibold mt-1">
                Store Hub
              </span>
            </div>

            {/* Road path line */}
            <div className="flex-1 mx-4 relative h-1 bg-zinc-800 rounded-full overflow-hidden">
              <motion.div
                initial={{ x: '-100%' }}
                animate={{ x: '100%' }}
                transition={{ repeat: Infinity, duration: 2.2, ease: 'linear' }}
                className="h-full w-24 bg-gradient-to-r from-transparent via-emerald-400 to-amber-300"
              />
            </div>

            {/* Animated Van */}
            <motion.div
              animate={{ y: [0, -3, 0] }}
              transition={{ repeat: Infinity, duration: 1.2, ease: 'easeInOut' }}
              className="absolute left-1/2 -translate-x-1/2 top-4 flex flex-col items-center"
            >
              <div className="p-2 rounded-xl bg-amber-400 text-zinc-900 shadow-md">
                <Bike className="w-4 h-4" />
              </div>
              <span className="text-[9px] font-mono text-amber-300 bg-black/60 px-1 rounded mt-0.5">
                On the Way
              </span>
            </motion.div>

            {/* Destination */}
            <div className="flex flex-col items-center text-center z-10">
              <div className="w-8 h-8 rounded-xl bg-amber-500 flex items-center justify-center shadow-lg shadow-amber-500/20 text-white">
                <MapPin className="w-4 h-4" />
              </div>
              <span className="text-[10px] text-zinc-400 font-semibold mt-1">
                Your Doorstep
              </span>
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between text-xs text-zinc-400">
            <span>Contactless doorstep drop enabled</span>
            <span className="text-emerald-400 font-bold">100% On-Time Target</span>
          </div>
        </div>
      </div>

      {/* Items in this order */}
      <div className="p-6 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm">
        <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-400 dark:text-zinc-500 mb-4">
          Order Summary ({order.items.length} items)
        </h4>

        <div className="divide-y divide-zinc-100 dark:divide-zinc-800">
          {order.items.map(({ product, quantity }) => (
            <div key={product.id} className="py-3 flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-3">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-10 h-10 rounded-xl object-cover bg-zinc-100 dark:bg-zinc-800"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <span className="font-bold text-zinc-900 dark:text-white block">
                    {product.name}
                  </span>
                  <span className="text-zinc-400 text-[11px]">
                    Qty: {quantity} • ₹{product.price.toFixed(2)} / {product.unit}
                  </span>
                </div>
              </div>

              <span className="font-bold font-mono text-zinc-900 dark:text-white">
                ₹{(product.price * quantity).toFixed(2)}
              </span>
            </div>
          ))}
        </div>

        <div className="pt-4 mt-2 border-t border-zinc-100 dark:border-zinc-800 flex justify-between items-baseline font-bold text-sm text-zinc-900 dark:text-white">
          <span>Total Paid ({order.paymentMethod})</span>
          <span className="text-base text-emerald-600 dark:text-emerald-400 font-mono">
            ₹{order.total.toFixed(2)}
          </span>
        </div>
      </div>
    </div>
  );
};
