import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Edit3, 
  Trash2, 
  Package, 
  DollarSign, 
  ShoppingBag, 
  TrendingUp, 
  Search, 
  Filter, 
  X, 
  Check, 
  AlertTriangle,
  RefreshCw,
  Layers,
  ArrowRight,
  ShieldCheck,
  Bike,
  Clock,
  Eye,
  SlidersHorizontal,
  ChevronDown,
  Database,
  Server,
  CheckCircle2,
  Copy,
  ExternalLink,
  Sparkles
} from 'lucide-react';
import { Product, Order, OrderStatus } from '../types';
import { 
  SUPABASE_PROJECT_ID, 
  SUPABASE_URL, 
  SUPABASE_ANON_KEY, 
  checkSupabaseHealth, 
  seedSupabaseProducts, 
  SupabaseHealth,
  subscribeToSupabaseProducts as subscribeToProducts,
  subscribeToAllSupabaseOrders as subscribeToAllOrders,
  addProductToSupabase as addProductToFirestore,
  updateProductInSupabase as updateProductInFirestore,
  deleteProductFromSupabase as deleteProductFromFirestore,
  updateOrderStatusInSupabase as updateOrderStatusInFirestore
} from '../lib/supabase';
import { supabase } from '../supabaseClient.js';
import { CATEGORIES } from '../data/seedProducts';
import { useAuth } from '../context/AuthContext';

const SUPABASE_SCHEMA_SQL = `-- SuperCart Supabase PostgreSQL Schema
-- Run in your Supabase SQL Editor: https://supabase.com/dashboard/project/wavkucsbhhcgnypntglt/sql

-- 1. Products Table
CREATE TABLE IF NOT EXISTS public.products (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  price NUMERIC NOT NULL,
  original_price NUMERIC,
  stock INTEGER DEFAULT 0,
  unit TEXT DEFAULT 'pack',
  image TEXT,
  description TEXT,
  rating NUMERIC DEFAULT 4.5,
  review_count INTEGER DEFAULT 12,
  badge TEXT,
  is_featured BOOLEAN DEFAULT FALSE,
  organic BOOLEAN DEFAULT FALSE,
  season TEXT,
  origin TEXT,
  ingredients JSONB DEFAULT '[]'::jsonb,
  nutrition JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Orders Table
CREATE TABLE IF NOT EXISTS public.orders (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  customer_name TEXT,
  customer_email TEXT,
  customer_phone TEXT,
  delivery_address TEXT,
  items JSONB NOT NULL DEFAULT '[]'::jsonb,
  subtotal NUMERIC NOT NULL DEFAULT 0,
  discount NUMERIC DEFAULT 0,
  discount_code TEXT,
  delivery_fee NUMERIC DEFAULT 0,
  tax NUMERIC DEFAULT 0,
  total NUMERIC NOT NULL DEFAULT 0,
  payment_method TEXT DEFAULT 'UPI / Net Banking',
  status TEXT DEFAULT 'Placed',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  estimated_delivery_time TEXT,
  driver_name TEXT,
  driver_phone TEXT,
  driver_vehicle TEXT,
  notes TEXT
);

-- 3. Profiles Table
CREATE TABLE IF NOT EXISTS public.profiles (
  id TEXT PRIMARY KEY,
  uid TEXT,
  email TEXT,
  name TEXT,
  phone TEXT,
  phone_number TEXT,
  phone_verified BOOLEAN DEFAULT FALSE,
  email_verified BOOLEAN DEFAULT FALSE,
  gender TEXT DEFAULT 'Prefer not to say',
  photo_url TEXT,
  avatar TEXT,
  address TEXT,
  saved_addresses JSONB DEFAULT '[]'::jsonb,
  role TEXT DEFAULT 'user',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Enable Row Level Security (RLS) & Access
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Public read products" ON public.products;
DROP POLICY IF EXISTS "Anon insert products" ON public.products;
DROP POLICY IF EXISTS "Anon update products" ON public.products;
DROP POLICY IF EXISTS "Anon delete products" ON public.products;

DROP POLICY IF EXISTS "Public read orders" ON public.orders;
DROP POLICY IF EXISTS "Anon insert orders" ON public.orders;
DROP POLICY IF EXISTS "Anon update orders" ON public.orders;

DROP POLICY IF EXISTS "Public read profiles" ON public.profiles;
DROP POLICY IF EXISTS "Anon insert profiles" ON public.profiles;
DROP POLICY IF EXISTS "Anon update profiles" ON public.profiles;

CREATE POLICY "Public read products" ON public.products FOR SELECT USING (true);
CREATE POLICY "Anon insert products" ON public.products FOR INSERT WITH CHECK (true);
CREATE POLICY "Anon update products" ON public.products FOR UPDATE USING (true);
CREATE POLICY "Anon delete products" ON public.products FOR DELETE USING (true);

CREATE POLICY "Public read orders" ON public.orders FOR SELECT USING (true);
CREATE POLICY "Anon insert orders" ON public.orders FOR INSERT WITH CHECK (true);
CREATE POLICY "Anon update orders" ON public.orders FOR UPDATE USING (true);

CREATE POLICY "Public read profiles" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Anon insert profiles" ON public.profiles FOR INSERT WITH CHECK (true);
CREATE POLICY "Anon update profiles" ON public.profiles FOR UPDATE USING (true);

-- 5. Enable Realtime Replication
DO $$
BEGIN
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.products;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;
END $$;`;

export const AdminDashboard: React.FC = () => {
  const { userProfile, updateRole } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeTab, setActiveTab] = useState<'inventory' | 'orders' | 'supabase'>('inventory');
  
  // Supabase states
  const [supabaseHealth, setSupabaseHealth] = useState<SupabaseHealth | null>(null);
  const [checkingSupabase, setCheckingSupabase] = useState(false);
  const [seedingSupabase, setSeedingSupabase] = useState(false);
  const [supabaseSeedMessage, setSupabaseSeedMessage] = useState<string | null>(null);
  const [copiedSql, setCopiedSql] = useState(false);
  
  // Product search & category filters
  const [productSearch, setProductSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  
  // Order status filter
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('All');

  // Product Add / Edit Modal
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  
  // Form values
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState<string>('Fruits & Veggies');
  const [formPrice, setFormPrice] = useState<number>(49);
  const [formOriginalPrice, setFormOriginalPrice] = useState<number>(65);
  const [formStock, setFormStock] = useState<number>(25);
  const [formUnit, setFormUnit] = useState('500g');
  const [formImage, setFormImage] = useState('https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80');
  const [formDescription, setFormDescription] = useState('Fresh hand-picked produce from local organic farms.');
  const [formOrganic, setFormOrganic] = useState(true);
  const [formSaving, setFormSaving] = useState(false);

  // Selected Order for detail preview
  const [inspectingOrder, setInspectingOrder] = useState<Order | null>(null);

  // Quick inline price editing state
  const [quickPriceEditId, setQuickPriceEditId] = useState<string | null>(null);
  const [quickPriceVal, setQuickPriceVal] = useState<number>(0);

  // Protect private page with supabase.auth.getSession() — if no session, redirect to /login
  useEffect(() => {
    let isMounted = true;
    async function verifyAuthSession() {
      try {
        const { data } = await supabase.auth.getSession();
        if (isMounted && !data?.session) {
          window.location.href = '/login';
        }
      } catch (err) {
        if (isMounted) {
          window.location.href = '/login';
        }
      }
    }
    verifyAuthSession();
    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    const unsubProds = subscribeToProducts((items) => {
      setProducts(items);
    });

    const unsubOrders = subscribeToAllOrders((allOrders) => {
      setOrders(allOrders);
    });

    // Run initial Supabase health check
    handleCheckSupabase();

    return () => {
      unsubProds();
      unsubOrders();
    };
  }, []);

  const handleCheckSupabase = async () => {
    setCheckingSupabase(true);
    try {
      const res = await checkSupabaseHealth();
      setSupabaseHealth(res);
    } catch (e: any) {
      console.warn('Supabase health check error:', e);
    } finally {
      setCheckingSupabase(false);
    }
  };

  const handleSeedSupabase = async () => {
    setSeedingSupabase(true);
    setSupabaseSeedMessage(null);
    try {
      const res = await seedSupabaseProducts();
      if (res.error) {
        setSupabaseSeedMessage(`Notice: ${res.error}. (Please run the SQL migration below in Supabase SQL editor first).`);
      } else {
        setSupabaseSeedMessage(`🎉 Successfully synced ${res.count} products to your Supabase PostgreSQL table!`);
      }
      handleCheckSupabase();
    } catch (e: any) {
      setSupabaseSeedMessage(`Error: ${e?.message || 'Failed to sync'}`);
    } finally {
      setSeedingSupabase(false);
    }
  };

  const handleCopySql = () => {
    try {
      navigator.clipboard.writeText(SUPABASE_SCHEMA_SQL);
      setCopiedSql(true);
      setTimeout(() => setCopiedSql(false), 3000);
    } catch {
      // fallback
    }
  };

  const openAddProductModal = () => {
    setEditingProduct(null);
    setFormName('');
    setFormCategory('Fruits & Veggies');
    setFormPrice(49);
    setFormOriginalPrice(65);
    setFormStock(20);
    setFormUnit('500g');
    setFormImage('https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80');
    setFormDescription('Farm fresh premium grocery item sourced responsibly.');
    setFormOrganic(false);
    setIsProductModalOpen(true);
  };

  const openEditProductModal = (prod: Product) => {
    setEditingProduct(prod);
    setFormName(prod.name);
    setFormCategory(prod.category);
    setFormPrice(prod.price);
    setFormOriginalPrice(prod.originalPrice || prod.price);
    setFormStock(prod.stock);
    setFormUnit(prod.unit);
    setFormImage(prod.image);
    setFormDescription(prod.description);
    setFormOrganic(!!prod.organic);
    setIsProductModalOpen(true);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormSaving(true);
    try {
      const payload: Omit<Product, 'id'> = {
        name: formName,
        category: formCategory,
        price: Number(formPrice),
        originalPrice: Number(formOriginalPrice),
        stock: Number(formStock),
        unit: formUnit,
        image: formImage,
        description: formDescription,
        organic: formOrganic,
        rating: editingProduct?.rating || 4.9,
        reviewCount: editingProduct?.reviewCount || 10
      };

      if (editingProduct) {
        await updateProductInFirestore(editingProduct.id, payload);
      } else {
        await addProductToFirestore(payload);
      }
      setIsProductModalOpen(false);
    } catch (err) {
      console.error('Save product error:', err);
    } finally {
      setFormSaving(false);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (confirm('Are you sure you want to remove this item from the catalog?')) {
      await deleteProductFromFirestore(id);
    }
  };

  const handleUpdateStatus = async (orderId: string, status: OrderStatus) => {
    await updateOrderStatusInFirestore(orderId, status);
  };

  const handleSaveQuickPrice = async (id: string) => {
    if (quickPriceVal > 0) {
      await updateProductInFirestore(id, { price: quickPriceVal });
    }
    setQuickPriceEditId(null);
  };

  // Metrics
  const totalRevenue = orders.reduce((sum, o) => sum + (o.status !== 'Cancelled' ? o.total : 0), 0);
  const activeOrders = orders.filter((o) => o.status !== 'Delivered' && o.status !== 'Cancelled');
  const lowStockCount = products.filter((p) => p.stock <= 5).length;

  const filteredProducts = products.filter((p) => {
    const matchCat = selectedCategory === 'All' || p.category === selectedCategory;
    const matchSearch = p.name.toLowerCase().includes(productSearch.toLowerCase());
    return matchCat && matchSearch;
  });

  const filteredOrders = orders.filter((o) => {
    if (orderStatusFilter === 'All') return true;
    return o.status === orderStatusFilter;
  });

  return (
    <div id="admin-dashboard-container" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 sm:p-8 rounded-3xl bg-zinc-900 text-white shadow-xl">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-0.5 rounded-full bg-amber-400 text-zinc-950 text-xs font-black uppercase tracking-wider">
              Admin Portal
            </span>
            <span className="text-xs text-zinc-400">Real-Time Store Management</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            SuperCart Inventory & Operations
          </h1>
          <p className="text-xs sm:text-sm text-zinc-400 mt-1">
            Live catalog updates, pricing controls, order fulfillment status, and analytics
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-zinc-800/90 border border-emerald-500/40 text-xs">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-semibold text-emerald-300">Supabase:</span>
            <span className="font-mono text-zinc-300">{SUPABASE_PROJECT_ID}</span>
          </div>

          <button
            onClick={openAddProductModal}
            className="px-4 py-2.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-bold text-xs shadow-lg shadow-emerald-500/20 transition flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Product</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-zinc-400 block mb-1">
              Total Gross Sales
            </span>
            <span className="text-2xl font-extrabold font-mono text-zinc-900 dark:text-white">
              ₹{totalRevenue.toFixed(2)}
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600">
            <DollarSign className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-zinc-400 block mb-1">
              Active In-Transit
            </span>
            <span className="text-2xl font-extrabold font-mono text-emerald-600 dark:text-emerald-400">
              {activeOrders.length} orders
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-purple-50 dark:bg-purple-950/60 text-purple-600">
            <Bike className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-zinc-400 block mb-1">
              Total Catalog SKUs
            </span>
            <span className="text-2xl font-extrabold font-mono text-zinc-900 dark:text-white">
              {products.length} products
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600">
            <Package className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200/80 dark:border-zinc-800 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-zinc-400 block mb-1">
              Low Stock Alerts
            </span>
            <span className="text-2xl font-extrabold font-mono text-amber-600 dark:text-amber-400">
              {lowStockCount} items
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/60 text-amber-600">
            <AlertTriangle className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Main Tab Controller */}
      <div className="flex border-b border-zinc-200 dark:border-zinc-800">
        <button
          onClick={() => setActiveTab('inventory')}
          className={`pb-4 px-6 font-bold text-sm border-b-2 transition flex items-center gap-2 ${
            activeTab === 'inventory'
              ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400'
              : 'border-transparent text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Product Catalog & Stock ({products.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`pb-4 px-6 font-bold text-sm border-b-2 transition flex items-center gap-2 ${
            activeTab === 'orders'
              ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400'
              : 'border-transparent text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>Customer Orders & Dispatch ({orders.length})</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('supabase');
            handleCheckSupabase();
          }}
          className={`pb-4 px-6 font-bold text-sm border-b-2 transition flex items-center gap-2 ${
            activeTab === 'supabase'
              ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400'
              : 'border-transparent text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100'
          }`}
        >
          <Database className="w-4 h-4 text-emerald-500" />
          <span>Supabase Backend</span>
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
            Live
          </span>
        </button>
      </div>

      {/* TAB 1: INVENTORY MANAGEMENT */}
      {activeTab === 'inventory' && (
        <div className="space-y-4">
          {/* Filter and Search Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-3" />
              <input
                type="text"
                value={productSearch}
                onChange={(e) => setProductSearch(e.target.value)}
                placeholder="Search products by title..."
                className="w-full pl-10 pr-4 py-2 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {['All', ...CATEGORIES.filter((c) => c !== 'All')].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition ${
                    selectedCategory === cat
                      ? 'bg-emerald-600 text-white'
                      : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Products Table */}
          <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200/80 dark:border-zinc-800 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-850/50 text-zinc-400 uppercase text-[10px] font-bold tracking-wider">
                    <th className="py-3 px-4">Product Info</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4">Unit / Weight</th>
                    <th className="py-3 px-4">Price (₹)</th>
                    <th className="py-3 px-4">Stock</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800">
                  {filteredProducts.map((prod) => (
                    <tr key={prod.id} className="hover:bg-zinc-50 dark:hover:bg-zinc-850/50 transition">
                      {/* Name and Image */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={prod.image}
                            alt={prod.name}
                            className="w-10 h-10 rounded-xl object-cover bg-zinc-100 dark:bg-zinc-800 shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          <div>
                            <span className="font-bold text-zinc-900 dark:text-white block line-clamp-1">
                              {prod.name}
                            </span>
                            {prod.organic && (
                              <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold">
                                Organic
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Category */}
                      <td className="py-3 px-4 text-zinc-600 dark:text-zinc-300">
                        {prod.category}
                      </td>

                      {/* Unit */}
                      <td className="py-3 px-4 font-mono text-zinc-500">
                        {prod.unit}
                      </td>

                      {/* Real-time Price editor */}
                      <td className="py-3 px-4">
                        {quickPriceEditId === prod.id ? (
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              step="0.01"
                              value={quickPriceVal}
                              onChange={(e) => setQuickPriceVal(Number(e.target.value))}
                              className="w-16 px-1.5 py-1 rounded border border-emerald-500 text-xs font-mono font-bold"
                              autoFocus
                            />
                            <button
                              onClick={() => handleSaveQuickPrice(prod.id)}
                              className="p-1 rounded bg-emerald-600 text-white"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <div
                            onClick={() => {
                              setQuickPriceEditId(prod.id);
                              setQuickPriceVal(prod.price);
                            }}
                            className="cursor-pointer group flex items-center gap-1 font-mono font-bold text-zinc-900 dark:text-white hover:text-emerald-600"
                            title="Click to edit price directly"
                          >
                            <span>₹{prod.price.toFixed(2)}</span>
                            <Edit3 className="w-3 h-3 text-zinc-300 group-hover:text-emerald-500 opacity-0 group-hover:opacity-100 transition" />
                          </div>
                        )}
                      </td>

                      {/* Stock */}
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded-full font-bold font-mono text-[11px] ${
                            prod.stock <= 0
                              ? 'bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-400'
                              : prod.stock <= 5
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                              : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          }`}
                        >
                          {prod.stock <= 0 ? 'Out of Stock' : `${prod.stock} units`}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => openEditProductModal(prod)}
                            className="p-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200 transition"
                            title="Edit Product Details"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteProduct(prod.id)}
                            className="p-1.5 rounded-lg bg-red-50 dark:bg-red-950/40 hover:bg-red-100 text-red-600 transition"
                            title="Delete Product"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: GLOBAL ORDERS MANAGEMENT */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          {/* Order Status Filters */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {['All', 'Placed', 'Processing', 'Out for Delivery', 'Delivered', 'Cancelled'].map((status) => (
              <button
                key={status}
                onClick={() => setOrderStatusFilter(status)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold capitalize transition ${
                  orderStatusFilter === status
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-200'
                }`}
              >
                {status}
              </button>
            ))}
          </div>

          {/* Orders Table */}
          <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200/80 dark:border-zinc-800 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-850/50 text-zinc-400 uppercase text-[10px] font-bold tracking-wider">
                    <th className="py-3 px-4">Order ID & Date</th>
                    <th className="py-3 px-4">Customer</th>
                    <th className="py-3 px-4">Destination</th>
                    <th className="py-3 px-4">Items / Total</th>
                    <th className="py-3 px-4">Change Status</th>
                    <th className="py-3 px-4 text-right">Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800">
                  {filteredOrders.map((order) => {
                    const dateStr = order.createdAt?.toDate
                      ? order.createdAt.toDate().toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
                      : 'Just Now';

                    return (
                      <tr key={order.id} className="hover:bg-zinc-50 dark:hover:bg-zinc-850/50 transition">
                        {/* ID */}
                        <td className="py-3 px-4">
                          <span className="font-mono font-bold text-zinc-900 dark:text-white block">
                            #{order.id.slice(0, 8).toUpperCase()}
                          </span>
                          <span className="text-[11px] text-zinc-400">{dateStr}</span>
                        </td>

                        {/* Customer */}
                        <td className="py-3 px-4">
                          <span className="font-bold text-zinc-900 dark:text-white block">
                            {order.customerName}
                          </span>
                          <span className="text-[11px] text-zinc-400">{order.customerEmail}</span>
                        </td>

                        {/* Destination */}
                        <td className="py-3 px-4 text-zinc-600 dark:text-zinc-300 max-w-[160px] truncate">
                          {order.deliveryAddress}
                        </td>

                        {/* Total */}
                        <td className="py-3 px-4">
                          <span className="font-bold font-mono text-zinc-900 dark:text-white block">
                            ₹{order.total.toFixed(2)}
                          </span>
                          <span className="text-[11px] text-zinc-400">
                            {order.items.length} items • {order.paymentMethod}
                          </span>
                        </td>

                        {/* Real-time Status dropdown */}
                        <td className="py-3 px-4">
                          <select
                            value={order.status}
                            onChange={(e) => handleUpdateStatus(order.id, e.target.value as OrderStatus)}
                            className={`px-3 py-1 rounded-xl text-xs font-bold border focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer ${
                              order.status === 'Placed'
                                ? 'bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border-blue-200'
                                : order.status === 'Processing'
                                ? 'bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 border-amber-200'
                                : order.status === 'Out for Delivery'
                                ? 'bg-purple-50 dark:bg-purple-950 text-purple-700 dark:text-purple-300 border-purple-200'
                                : order.status === 'Delivered'
                                ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border-emerald-200'
                                : 'bg-zinc-100 text-zinc-700 border-zinc-200'
                            }`}
                          >
                            <option value="Placed">Placed</option>
                            <option value="Processing">Processing</option>
                            <option value="Out for Delivery">Out for Delivery</option>
                            <option value="Delivered">Delivered</option>
                            <option value="Cancelled">Cancelled</option>
                          </select>
                        </td>

                        {/* View Breakdown */}
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => setInspectingOrder(order)}
                            className="p-1.5 rounded-lg bg-zinc-100 dark:bg-zinc-800 hover:bg-zinc-200 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-200 transition"
                            title="Inspect Order Breakdown"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: SUPABASE BACKEND MANAGEMENT */}
      {activeTab === 'supabase' && (
        <div className="space-y-6">
          {/* Main Status & Configuration Card */}
          <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-sm space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-zinc-100 dark:border-zinc-800">
              <div className="flex items-start gap-4">
                <div className="p-3.5 rounded-2xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                  <Database className="w-8 h-8" />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h2 className="text-xl font-extrabold text-zinc-900 dark:text-white">
                      Supabase Cloud Backend
                    </h2>
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-800">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      Active & Connected
                    </span>
                  </div>
                  <p className="text-xs text-zinc-500 dark:text-zinc-400">
                    Your SuperCart application is linked to Supabase PostgreSQL database and real-time streaming engine.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleCheckSupabase}
                  disabled={checkingSupabase}
                  className="px-4 py-2 rounded-xl bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 text-xs font-bold transition flex items-center gap-2 disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${checkingSupabase ? 'animate-spin' : ''}`} />
                  <span>{checkingSupabase ? 'Testing...' : 'Test Connection'}</span>
                </button>

                <a
                  href={`https://supabase.com/dashboard/project/${SUPABASE_PROJECT_ID}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md shadow-emerald-600/20 transition flex items-center gap-2"
                >
                  <span>Open Supabase Console</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>

            {/* Credentials & Connection Summary */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-850 border border-zinc-200/80 dark:border-zinc-800">
                <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 block mb-1">
                  Project Reference ID
                </span>
                <span className="text-sm font-mono font-bold text-zinc-900 dark:text-zinc-100 select-all">
                  {SUPABASE_PROJECT_ID}
                </span>
              </div>

              <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-850 border border-zinc-200/80 dark:border-zinc-800">
                <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 block mb-1">
                  REST API Endpoint
                </span>
                <span className="text-sm font-mono font-bold text-zinc-900 dark:text-zinc-100 truncate block select-all" title={SUPABASE_URL}>
                  {SUPABASE_URL}
                </span>
              </div>

              <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-850 border border-zinc-200/80 dark:border-zinc-800">
                <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 block mb-1">
                  Anon / Publishable API Key
                </span>
                <span className="text-sm font-mono font-bold text-zinc-900 dark:text-zinc-100 truncate block select-all" title={SUPABASE_ANON_KEY}>
                  {SUPABASE_ANON_KEY.slice(0, 16)}...
                </span>
              </div>
            </div>
          </div>

          {/* Database Tables & Diagnostics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Products Table */}
            <div className="p-5 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Package className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    <span className="font-extrabold text-sm text-zinc-900 dark:text-white">public.products</span>
                  </div>
                  {supabaseHealth?.tables?.products ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                      Table Ready
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300">
                      Needs SQL Run
                    </span>
                  )}
                </div>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 mb-4">
                  Stores {products.length} grocery items with INR pricing, stock levels, nutritional specs, and badges.
                </p>
              </div>

              <button
                onClick={handleSeedSupabase}
                disabled={seedingSupabase}
                className="w-full py-2.5 px-3 rounded-xl bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/60 dark:hover:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-xs font-bold transition flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{seedingSupabase ? 'Pushing to Supabase...' : 'Sync Products to Supabase'}</span>
              </button>
            </div>

            {/* Orders Table */}
            <div className="p-5 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <ShoppingBag className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                    <span className="font-extrabold text-sm text-zinc-900 dark:text-white">public.orders</span>
                  </div>
                  {supabaseHealth?.tables?.orders ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                      Table Ready
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300">
                      Needs SQL Run
                    </span>
                  )}
                </div>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 mb-4">
                  Records checkout orders, payment methods, delivery addresses, and real-time transit status updates.
                </p>
              </div>

              <div className="py-2.5 px-3 rounded-xl bg-zinc-50 dark:bg-zinc-850 border border-zinc-200/80 dark:border-zinc-800 text-xs text-zinc-500 flex items-center justify-between">
                <span>Total Live Orders:</span>
                <span className="font-mono font-bold text-zinc-800 dark:text-zinc-200">{orders.length}</span>
              </div>
            </div>

            {/* Profiles Table */}
            <div className="p-5 rounded-3xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    <span className="font-extrabold text-sm text-zinc-900 dark:text-white">public.profiles</span>
                  </div>
                  {supabaseHealth?.tables?.profiles ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                      Table Ready
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300">
                      Needs SQL Run
                    </span>
                  )}
                </div>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 mb-4">
                  Stores customer profiles, verified mobile numbers, delivery address books, and role permissions.
                </p>
              </div>

              <div className="py-2.5 px-3 rounded-xl bg-zinc-50 dark:bg-zinc-850 border border-zinc-200/80 dark:border-zinc-800 text-xs text-zinc-500 flex items-center justify-between">
                <span>Active Profile:</span>
                <span className="font-bold text-zinc-800 dark:text-zinc-200 truncate max-w-[120px]">
                  {userProfile?.name || 'Customer'}
                </span>
              </div>
            </div>
          </div>

          {/* Seed Feedback Banner */}
          {supabaseSeedMessage && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs font-semibold flex items-center justify-between"
            >
              <span>{supabaseSeedMessage}</span>
              <button
                onClick={() => setSupabaseSeedMessage(null)}
                className="text-emerald-600 hover:text-emerald-800 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          )}

          {/* SQL Migration Script Box */}
          <div className="p-6 sm:p-8 rounded-3xl bg-zinc-900 text-white shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-extrabold uppercase">
                    Setup Guide
                  </span>
                  <h3 className="font-extrabold text-base">
                    Supabase PostgreSQL Migration Script
                  </h3>
                </div>
                <p className="text-xs text-zinc-400">
                  To ensure full tables and Row Level Security (RLS) are active in your Supabase project, run this SQL in your Supabase SQL Editor:
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopySql}
                  className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 text-xs font-bold transition flex items-center gap-2"
                >
                  {copiedSql ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy SQL Schema</span>
                    </>
                  )}
                </button>

                <a
                  href={`https://supabase.com/dashboard/project/${SUPABASE_PROJECT_ID}/sql`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-bold transition flex items-center gap-2"
                >
                  <span>Open SQL Editor</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>

            <div className="relative">
              <pre className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 text-[11px] font-mono text-emerald-400/90 overflow-x-auto max-h-72 select-all">
                {SUPABASE_SCHEMA_SQL}
              </pre>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs text-zinc-400 pt-2 border-t border-zinc-800">
              <span>Saved file available in repository root: <code className="text-emerald-400 font-mono">/supabase-schema.sql</code></span>
              <span className="text-[11px] text-zinc-500 mt-1 sm:mt-0">Includes tables, indexes, RLS policies, and realtime broadcast publications</span>
            </div>
          </div>
        </div>
      )}
      {isProductModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative w-full max-w-xl bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border border-zinc-200 dark:border-zinc-800 p-6 md:p-8 text-zinc-900 dark:text-zinc-100 my-8"
          >
            <button
              onClick={() => setIsProductModalOpen(false)}
              className="absolute top-5 right-5 p-2 rounded-full text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-bold text-zinc-900 dark:text-white mb-1">
              {editingProduct ? 'Edit Grocery Product' : 'Add New Grocery Product'}
            </h3>
            <p className="text-xs text-zinc-500 dark:text-zinc-400 mb-6">
              Product details will immediately sync with user storefronts via Firestore.
            </p>

            <form onSubmit={handleSaveProduct} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1">
                  Product Name / Title
                </label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. Fresh Organic Blueberries (Pack of 2)"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-xs focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1">
                    Category
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-xs focus:ring-2 focus:ring-emerald-500"
                  >
                    {CATEGORIES.filter((c) => c !== 'All').map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1">
                    Unit / Size
                  </label>
                  <input
                    type="text"
                    required
                    value={formUnit}
                    onChange={(e) => setFormUnit(e.target.value)}
                    placeholder="e.g. 500g, 1L, 12 pcs"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1">
                    Selling Price (₹)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={formPrice}
                    onChange={(e) => setFormPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-xs font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1">
                    Original Price (₹)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={formOriginalPrice}
                    onChange={(e) => setFormOriginalPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1">
                    Stock Units
                  </label>
                  <input
                    type="number"
                    required
                    value={formStock}
                    onChange={(e) => setFormStock(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-xs font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1">
                  Image URL (Unsplash or direct CDN link)
                </label>
                <input
                  type="url"
                  required
                  value={formImage}
                  onChange={(e) => setFormImage(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 mb-1">
                  Item Description
                </label>
                <textarea
                  rows={3}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-xs"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="organic-check"
                  checked={formOrganic}
                  onChange={(e) => setFormOrganic(e.target.checked)}
                  className="w-4 h-4 accent-emerald-600 cursor-pointer"
                />
                <label htmlFor="organic-check" className="text-xs font-semibold text-zinc-700 dark:text-zinc-300 cursor-pointer">
                  Mark as 100% Organic Produce
                </label>
              </div>

              <button
                type="submit"
                disabled={formSaving}
                className="w-full py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/20 transition disabled:opacity-60"
              >
                {formSaving ? 'Saving to Database...' : editingProduct ? 'Update Product' : 'Add to Live Catalog'}
              </button>
            </form>
          </motion.div>
        </div>
      )}

      {/* Inspect Order Modal */}
      {inspectingOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative w-full max-w-lg bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border border-zinc-200 dark:border-zinc-800 p-6 text-zinc-900 dark:text-zinc-100"
          >
            <button
              onClick={() => setInspectingOrder(null)}
              className="absolute top-5 right-5 p-2 rounded-full text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="font-extrabold text-base text-zinc-900 dark:text-white mb-1">
              Order Breakdown #{inspectingOrder.id.slice(0, 8).toUpperCase()}
            </h3>
            <p className="text-xs text-zinc-400 mb-4">
              Customer: {inspectingOrder.customerName} ({inspectingOrder.customerEmail})
            </p>

            <div className="p-3.5 rounded-2xl bg-zinc-50 dark:bg-zinc-850 border border-zinc-200/80 dark:border-zinc-800 text-xs mb-4">
              <span className="font-bold text-zinc-500 block mb-1">Address:</span>
              <p className="text-zinc-800 dark:text-zinc-200">{inspectingOrder.deliveryAddress}</p>
            </div>

            <div className="max-h-56 overflow-y-auto divide-y divide-zinc-100 dark:divide-zinc-800 mb-4">
              {inspectingOrder.items.map(({ product, quantity }) => (
                <div key={product.id} className="py-2.5 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <img src={product.image} className="w-8 h-8 rounded-lg object-cover" alt="" />
                    <div>
                      <span className="font-bold block">{product.name}</span>
                      <span className="text-zinc-400">Qty: {quantity} • ₹{product.price.toFixed(2)}</span>
                    </div>
                  </div>
                  <span className="font-bold font-mono">₹{(product.price * quantity).toFixed(2)}</span>
                </div>
              ))}
            </div>

            <div className="border-t border-zinc-100 dark:border-zinc-800 pt-3 flex justify-between font-extrabold text-sm">
              <span>Grand Total:</span>
              <span className="text-emerald-600 font-mono">₹{inspectingOrder.total.toFixed(2)}</span>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};
