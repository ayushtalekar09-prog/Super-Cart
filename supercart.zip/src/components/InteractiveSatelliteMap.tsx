import React, { useEffect, useRef, useState, useCallback } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { 
  Navigation, 
  ZoomIn, 
  ZoomOut, 
  Layers, 
  CheckCircle2, 
  MapPin, 
  Compass,
  Crosshair,
  Loader2
} from 'lucide-react';
import { INDIAN_LOCALITIES_DATABASE, LocalityItem } from '../data/indianLocations';

interface InteractiveSatelliteMapProps {
  initialCoords: { lat: number; lng: number } | null;
  selectedAddress: string;
  onSelectLocation: (address: string, coords: { lat: number; lng: number }) => void;
}

// Quick metro hubs to quickly jump satellite camera to user's region
const METRO_HUBS = [
  { name: 'Mumbai', lat: 19.0760, lng: 72.8777, zoom: 13 },
  { name: 'Bengaluru', lat: 12.9716, lng: 77.5946, zoom: 13 },
  { name: 'Delhi NCR', lat: 28.6139, lng: 77.2090, zoom: 13 },
  { name: 'Pune', lat: 18.5204, lng: 73.8567, zoom: 13 },
  { name: 'Hyderabad', lat: 17.3850, lng: 78.4867, zoom: 13 },
  { name: 'Chennai', lat: 13.0827, lng: 80.2707, zoom: 13 }
];

// Calculate Haversine distance in kilometers
function getDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// Find nearest locality in our database
function findNearestLocality(lat: number, lng: number): { locality: LocalityItem; distanceKm: number } {
  let nearest = INDIAN_LOCALITIES_DATABASE[0];
  let minDistance = getDistanceKm(lat, lng, nearest.lat, nearest.lng);

  for (let i = 1; i < INDIAN_LOCALITIES_DATABASE.length; i++) {
    const item = INDIAN_LOCALITIES_DATABASE[i];
    const dist = getDistanceKm(lat, lng, item.lat, item.lng);
    if (dist < minDistance) {
      minDistance = dist;
      nearest = item;
    }
  }

  return { locality: nearest, distanceKm: minDistance };
}

export const InteractiveSatelliteMap: React.FC<InteractiveSatelliteMapProps> = ({
  initialCoords,
  selectedAddress,
  onSelectLocation
}) => {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);
  
  const [currentCoords, setCurrentCoords] = useState<{ lat: number; lng: number }>(
    initialCoords || { lat: 19.0760, lng: 72.8777 } // Default to Mumbai center
  );
  const [isResolving, setIsResolving] = useState<boolean>(false);
  const [activeLocalityName, setActiveLocalityName] = useState<string>(selectedAddress || 'Mumbai, Maharashtra');
  const [activeLayerType, setActiveLayerType] = useState<'satellite' | 'street'>('satellite');
  const [isLocatingUser, setIsLocatingUser] = useState<boolean>(false);

  // Custom high-contrast SVG marker icon with pulse wave
  const createPinIcon = (label?: string) => {
    return L.divIcon({
      className: 'supercart-satellite-marker',
      html: `
        <div style="position: relative; display: flex; flex-direction: column; align-items: center; transform: translate(-50%, -100%); cursor: pointer;">
          <div style="
            position: absolute; 
            bottom: -4px; 
            width: 24px; 
            height: 24px; 
            background: rgba(16, 185, 129, 0.4); 
            border-radius: 50%; 
            animation: ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite;
          "></div>
          <div style="
            background: linear-gradient(135deg, #059669, #047857);
            color: #ffffff;
            border: 2px solid #ffffff;
            border-radius: 9999px;
            padding: 6px 10px;
            display: flex;
            align-items: center;
            gap: 6px;
            box-shadow: 0 4px 14px rgba(0,0,0,0.6);
            font-size: 11px;
            font-weight: 800;
            white-space: nowrap;
          ">
            <span style="display: inline-block; width: 8px; height: 8px; border-radius: 50%; background: #34d399;"></span>
            <span>${label || 'Deliver Here (15m)'}</span>
          </div>
          <div style="
            width: 0; 
            height: 0; 
            border-left: 7px solid transparent; 
            border-right: 7px solid transparent; 
            border-top: 9px solid #047857; 
            margin-top: -1px;
            filter: drop-shadow(0 2px 2px rgba(0,0,0,0.5));
          "></div>
        </div>
      `,
      iconSize: [0, 0],
      iconAnchor: [0, 0]
    });
  };

  // Reverse geocode clicked coordinates
  const resolveLocationFromCoords = useCallback(async (lat: number, lng: number) => {
    setIsResolving(true);
    const { locality, distanceKm } = findNearestLocality(lat, lng);

    let addressString = '';

    // If within ~12km of an indexed locality, prioritize our structured delivery database
    if (distanceKm <= 12) {
      addressString = `${locality.name}, PIN: ${locality.pincode}`;
    } else {
      // Try fast reverse lookup with 1500ms timeout
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 1600);
        const resp = await fetch(
          `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=16`,
          { signal: controller.signal }
        );
        clearTimeout(timeoutId);
        if (resp.ok) {
          const data = await resp.json();
          if (data && data.display_name) {
            const parts = data.display_name.split(',').map((s: string) => s.trim());
            const shortAddress = parts.slice(0, 4).join(', ');
            addressString = `${shortAddress}, India`;
          }
        }
      } catch (err) {
        // Fallback to nearest locality
      }

      if (!addressString) {
        addressString = `${locality.locality}, near ${locality.city}, ${locality.state} (Satellite Picked: ${lat.toFixed(4)}° N, ${lng.toFixed(4)}° E)`;
      }
    }

    setActiveLocalityName(addressString);
    setIsResolving(false);
    onSelectLocation(addressString, { lat, lng });

    // Update marker icon with fresh label
    if (markerRef.current) {
      markerRef.current.setIcon(createPinIcon(locality.locality || 'Deliver Here'));
    }
  }, [onSelectLocation]);

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapInstanceRef.current) return; // already initialized

    const initialLat = initialCoords?.lat || 19.0760;
    const initialLng = initialCoords?.lng || 72.8777;

    const map = L.map(mapContainerRef.current, {
      center: [initialLat, initialLng],
      zoom: 13,
      zoomControl: false,
      attributionControl: false,
      maxBounds: [
        [5.0, 65.0], // South-West India bounding box
        [38.0, 99.0]  // North-East India bounding box
      ],
      minZoom: 4,
      maxZoom: 18
    });

    // High resolution Minimal Esri Satellite Imagery
    const satelliteLayer = L.tileLayer(
      'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      {
        maxZoom: 18,
        attribution: 'Esri World Imagery'
      }
    );

    // Alternative OpenStreetMap tiles for street reference
    const streetLayer = L.tileLayer(
      'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      {
        maxZoom: 18,
        attribution: 'OpenStreetMap'
      }
    );

    satelliteLayer.addTo(map);
    (map as any)._satelliteLayer = satelliteLayer;
    (map as any)._streetLayer = streetLayer;

    // Create delivery marker
    const marker = L.marker([initialLat, initialLng], {
      icon: createPinIcon(selectedAddress ? selectedAddress.split(',')[0] : 'Deliver Here'),
      draggable: true
    }).addTo(map);

    // When marker is dragged
    marker.on('dragend', (e) => {
      const position = e.target.getLatLng();
      setCurrentCoords({ lat: position.lat, lng: position.lng });
      resolveLocationFromCoords(position.lat, position.lng);
    });

    // DIRECT SATELLITE PICKING: Clicking ANYWHERE on the satellite map sets the delivery location!
    map.on('click', (e: L.LeafletMouseEvent) => {
      const { lat, lng } = e.latlng;
      marker.setLatLng([lat, lng]);
      setCurrentCoords({ lat, lng });
      resolveLocationFromCoords(lat, lng);
    });

    markerRef.current = marker;
    mapInstanceRef.current = map;

    // Invalidate map size after animation/render
    const timer = setTimeout(() => {
      map.invalidateSize();
    }, 200);

    return () => {
      clearTimeout(timer);
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update map center when initialCoords changes
  useEffect(() => {
    if (initialCoords && mapInstanceRef.current && markerRef.current) {
      mapInstanceRef.current.setView([initialCoords.lat, initialCoords.lng], 14, { animate: true });
      markerRef.current.setLatLng([initialCoords.lat, initialCoords.lng]);
      setCurrentCoords(initialCoords);
      if (selectedAddress) {
        setActiveLocalityName(selectedAddress);
      }
    }
  }, [initialCoords, selectedAddress]);

  // Toggle Satellite vs Street map layers
  const handleToggleLayer = (type: 'satellite' | 'street') => {
    if (!mapInstanceRef.current) return;
    const map = mapInstanceRef.current as any;

    if (type === 'satellite') {
      if (map._streetLayer) map.removeLayer(map._streetLayer);
      if (map._satelliteLayer) map.addLayer(map._satelliteLayer);
    } else {
      if (map._satelliteLayer) map.removeLayer(map._satelliteLayer);
      if (map._streetLayer) map.addLayer(map._streetLayer);
    }
    setActiveLayerType(type);
  };

  // Zoom helpers
  const handleZoomIn = () => {
    mapInstanceRef.current?.zoomIn();
  };

  const handleZoomOut = () => {
    mapInstanceRef.current?.zoomOut();
  };

  // Pan to metro hub
  const handleJumpToMetro = (metro: typeof METRO_HUBS[0]) => {
    if (!mapInstanceRef.current || !markerRef.current) return;
    mapInstanceRef.current.setView([metro.lat, metro.lng], metro.zoom, { animate: true });
    markerRef.current.setLatLng([metro.lat, metro.lng]);
    setCurrentCoords({ lat: metro.lat, lng: metro.lng });
    resolveLocationFromCoords(metro.lat, metro.lng);
  };

  // GPS Current Location on Satellite Map
  const handleLocateMe = () => {
    if (!navigator.geolocation) return;
    setIsLocatingUser(true);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        setIsLocatingUser(false);
        if (mapInstanceRef.current && markerRef.current) {
          mapInstanceRef.current.setView([lat, lng], 15, { animate: true });
          markerRef.current.setLatLng([lat, lng]);
          setCurrentCoords({ lat, lng });
          resolveLocationFromCoords(lat, lng);
        }
      },
      (err) => {
        console.warn('Satellite GPS geolocation note:', err);
        setIsLocatingUser(false);
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  return (
    <div className="rounded-2xl border-2 border-emerald-500/40 bg-zinc-950 overflow-hidden shadow-xl space-y-0">
      
      {/* 1. Header Toolbar with Satellite Switch & Status */}
      <div className="px-3.5 py-2.5 bg-zinc-900 border-b border-zinc-800 flex items-center justify-between gap-2 flex-wrap text-xs">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 text-emerald-400 font-extrabold">
            <Layers className="w-4 h-4 text-emerald-400" />
            <span>Minimal Satellite View</span>
          </div>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
            Click to Pick
          </span>
        </div>

        {/* Layer Mode Toggle (Satellite vs Street) */}
        <div className="flex items-center gap-1 bg-zinc-800 p-0.5 rounded-xl border border-zinc-700">
          <button
            type="button"
            onClick={() => handleToggleLayer('satellite')}
            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${
              activeLayerType === 'satellite'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Satellite
          </button>
          <button
            type="button"
            onClick={() => handleToggleLayer('street')}
            className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition cursor-pointer ${
              activeLayerType === 'street'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Street Map
          </button>
        </div>
      </div>

      {/* 2. Interactive Map Container with Click-to-Select */}
      <div className="relative w-full h-64 sm:h-72 bg-zinc-950 cursor-crosshair">
        
        {/* Leaflet Mount Target */}
        <div ref={mapContainerRef} className="w-full h-full" style={{ zIndex: 1 }} />

        {/* Subtle Crosshair Guidance Watermark */}
        <div className="absolute top-2 left-2 z-20 pointer-events-none">
          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-black/80 text-white backdrop-blur-md text-[11px] font-bold border border-emerald-500/40 shadow-lg">
            <Crosshair className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>Tap anywhere on satellite map to choose delivery location</span>
          </div>
        </div>

        {/* Resolving / Reverse Geocoding Indicator */}
        {isResolving && (
          <div className="absolute inset-0 z-30 bg-black/40 backdrop-blur-xs flex items-center justify-center pointer-events-none">
            <div className="px-4 py-2 rounded-2xl bg-zinc-900/90 text-white border border-emerald-500/50 shadow-2xl flex items-center gap-2 text-xs font-bold">
              <Loader2 className="w-4 h-4 text-emerald-400 animate-spin" />
              <span>Matching satellite coordinates to Indian delivery hub...</span>
            </div>
          </div>
        )}

        {/* Map On-Screen Controls (+ / - / GPS) */}
        <div className="absolute right-2.5 bottom-2.5 z-20 flex flex-col gap-1.5 shadow-lg">
          <button
            type="button"
            onClick={handleLocateMe}
            disabled={isLocatingUser}
            className="p-2 rounded-xl bg-zinc-900/90 hover:bg-emerald-700 text-white border border-zinc-700 hover:border-emerald-500 transition cursor-pointer"
            title="Locate my GPS on satellite"
          >
            <Navigation className={`w-4 h-4 ${isLocatingUser ? 'animate-spin text-emerald-400' : ''}`} />
          </button>
          <button
            type="button"
            onClick={handleZoomIn}
            className="p-2 rounded-xl bg-zinc-900/90 hover:bg-zinc-800 text-white border border-zinc-700 transition cursor-pointer"
            title="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={handleZoomOut}
            className="p-2 rounded-xl bg-zinc-900/90 hover:bg-zinc-800 text-white border border-zinc-700 transition cursor-pointer"
            title="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
        </div>

        {/* Coordinate indicator at bottom left */}
        <div className="absolute left-2.5 bottom-2.5 z-20 pointer-events-none">
          <div className="px-2 py-1 rounded-md bg-black/80 text-[10px] text-zinc-300 font-mono border border-zinc-800 backdrop-blur-xs">
            {currentCoords.lat.toFixed(4)}° N, {currentCoords.lng.toFixed(4)}° E
          </div>
        </div>
      </div>

      {/* 3. Metro Region Jump Shortcuts for Quick Satellite Positioning */}
      <div className="p-2.5 bg-zinc-900 border-t border-zinc-800 space-y-1.5">
        <div className="flex items-center justify-between text-[10px] font-bold text-zinc-400 px-1">
          <span className="uppercase tracking-wider">Quick Satellite Hub Presets:</span>
          <span>Tap to fly camera to city</span>
        </div>
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {METRO_HUBS.map((metro) => (
            <button
              key={metro.name}
              type="button"
              onClick={() => handleJumpToMetro(metro)}
              className="px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-emerald-950 border border-zinc-700 hover:border-emerald-500/50 text-[11px] font-bold text-zinc-200 hover:text-emerald-300 transition whitespace-nowrap cursor-pointer shrink-0"
            >
              📍 {metro.name}
            </button>
          ))}
        </div>
      </div>

      {/* 4. Active Selection Result Banner */}
      <div className="p-3 bg-zinc-950 border-t border-zinc-800 flex items-center justify-between gap-3">
        <div className="min-w-0 flex-1">
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-400 block">
            Selected from Satellite:
          </span>
          <p className="text-xs sm:text-sm font-bold text-white truncate">
            {activeLocalityName}
          </p>
        </div>
        <div className="flex items-center gap-1.5 text-xs font-black text-emerald-400 shrink-0 bg-emerald-950/80 px-2.5 py-1 rounded-xl border border-emerald-500/40">
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>15m Delivery</span>
        </div>
      </div>

    </div>
  );
};
