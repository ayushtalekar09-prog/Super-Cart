import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  MapPin, 
  Navigation, 
  Search, 
  AlertCircle,
  Compass,
  ArrowRight,
  CheckCircle2
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { 
  INDIAN_LOCALITIES_DATABASE, 
  searchIndianLocationsWithNearby,
  LocalityItem 
} from '../data/indianLocations';
import { InteractiveSatelliteMap } from './InteractiveSatelliteMap';

interface LocationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// Major Indian Reference Locations for verification and quick-selection
interface IndianLocation {
  name: string;
  state: string;
  pincode: string;
  lat: number;
  lng: number;
}

const INDIAN_CITIES_DATABASE: IndianLocation[] = [
  { name: 'Mumbai, Maharashtra', state: 'Maharashtra', pincode: '400001', lat: 19.0760, lng: 72.8777 },
  { name: 'Pune, Maharashtra', state: 'Maharashtra', pincode: '411001', lat: 18.5204, lng: 73.8567 },
  { name: 'Bengaluru, Karnataka', state: 'Karnataka', pincode: '560001', lat: 12.9716, lng: 77.5946 },
  { name: 'Delhi NCR (New Delhi)', state: 'Delhi', pincode: '110001', lat: 28.6139, lng: 77.2090 },
  { name: 'Hyderabad, Telangana', state: 'Telangana', pincode: '500001', lat: 17.3850, lng: 78.4867 },
  { name: 'Chennai, Tamil Nadu', state: 'Tamil Nadu', pincode: '600001', lat: 13.0827, lng: 80.2707 },
  { name: 'Kolkata, West Bengal', state: 'West Bengal', pincode: '700001', lat: 22.5726, lng: 88.3639 },
  { name: 'Ahmedabad, Gujarat', state: 'Gujarat', pincode: '380001', lat: 23.0225, lng: 72.5714 },
  { name: 'Jaipur, Rajasthan', state: 'Rajasthan', pincode: '302001', lat: 26.9124, lng: 75.7873 },
  { name: 'Lucknow, Uttar Pradesh', state: 'Uttar Pradesh', pincode: '226001', lat: 26.8467, lng: 80.9462 },
  { name: 'Nagpur, Maharashtra', state: 'Maharashtra', pincode: '440001', lat: 21.1458, lng: 79.0882 },
  { name: 'Chandigarh', state: 'Punjab & Haryana', pincode: '160001', lat: 30.7333, lng: 76.7794 },
  { name: 'Indore, Madhya Pradesh', state: 'Madhya Pradesh', pincode: '452001', lat: 22.7196, lng: 75.8577 },
  { name: 'Kochi, Kerala', state: 'Kerala', pincode: '682001', lat: 9.9312, lng: 76.2673 },
  { name: 'Goa (Panaji)', state: 'Goa', pincode: '403001', lat: 15.4909, lng: 73.8278 }
];

export const LocationModal: React.FC<LocationModalProps> = ({ isOpen, onClose }) => {
  const { userProfile, updateDeliveryAddress } = useAuth();
  const { t } = useLanguage();
  
  const [searchInput, setSearchInput] = useState('');
  const [selectedLocation, setSelectedLocation] = useState<string>(userProfile?.address || '');
  const [selectedCoords, setSelectedCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [selectedSuccessToast, setSelectedSuccessToast] = useState<string | null>(null);

  useEffect(() => {
    if (userProfile?.address) {
      setSelectedLocation(userProfile.address);
      
      const lower = userProfile.address.toLowerCase();
      const matched = INDIAN_CITIES_DATABASE.find(c => 
        lower.includes(c.name.toLowerCase().split(',')[0]) || 
        (c.pincode && lower.includes(c.pincode))
      );
      if (matched) {
        setSelectedCoords({ lat: matched.lat, lng: matched.lng });
      }
    } else {
      setSelectedLocation('');
      setSelectedCoords(null);
    }
  }, [userProfile?.address, isOpen]);

  // Live Location and Nearby suggestions as user types
  const searchSuggestions = useMemo(() => {
    if (!searchInput.trim() || searchInput.trim().length < 2) {
      return { matches: [], nearbySuggestions: [] };
    }
    return searchIndianLocationsWithNearby(searchInput);
  }, [searchInput]);

  if (!isOpen) return null;

  // Validation function: Check if coordinate is within India bounds
  const isCoordinatesInIndia = (lat: number, lng: number): boolean => {
    return lat >= 6.5 && lat <= 37.5 && lng >= 68.0 && lng <= 97.5;
  };

  // Validate Indian address text, Google Maps link, or PIN
  const validateIndianAddress = (text: string): { valid: boolean; normalized?: string; coords?: { lat: number; lng: number } } => {
    const trimmed = text.trim();
    if (!trimmed || trimmed.length < 2) {
      return { valid: false };
    }

    // Check if input is a Google Maps URL containing coordinates or place name
    if (trimmed.includes('google.com/maps') || trimmed.includes('maps.app.goo.gl')) {
      const coordMatch = trimmed.match(/@(-?\d+\.\d+),(-?\d+\.\d+)/);
      if (coordMatch) {
        const lat = parseFloat(coordMatch[1]);
        const lng = parseFloat(coordMatch[2]);
        return {
          valid: true,
          normalized: `Selected Map Location (${lat.toFixed(4)}, ${lng.toFixed(4)}), India`,
          coords: { lat, lng }
        };
      }
      const placeMatch = trimmed.match(/place\/([^/@?]+)/);
      if (placeMatch) {
        const placeName = decodeURIComponent(placeMatch[1].replace(/\+/g, ' '));
        return {
          valid: true,
          normalized: `${placeName}, India`
        };
      }
    }

    // Check against Indian PIN code (6 digits)
    const pinMatch = trimmed.match(/\b\d{6}\b/);
    if (pinMatch) {
      const pin = pinMatch[0];
      const foundCity = INDIAN_CITIES_DATABASE.find(c => c.pincode === pin);
      if (foundCity) {
        return { valid: true, normalized: `${trimmed}, India`, coords: { lat: foundCity.lat, lng: foundCity.lng } };
      }
      return { valid: true, normalized: `${trimmed}, India` };
    }

    // Check if contains Indian city or state keyword
    const lower = trimmed.toLowerCase();
    const matchedCity = INDIAN_CITIES_DATABASE.find(c => 
      lower.includes(c.name.toLowerCase().split(',')[0]) || 
      lower.includes(c.state.toLowerCase())
    );

    if (matchedCity) {
      return { 
        valid: true, 
        normalized: `${trimmed}${trimmed.toLowerCase().includes('india') ? '' : ', India'}`, 
        coords: { lat: matchedCity.lat, lng: matchedCity.lng } 
      };
    }

    // Common Indian states & territories
    const indianStates = [
      'maharashtra', 'karnataka', 'delhi', 'gujarat', 'rajasthan', 'tamil nadu', 
      'kerala', 'telangana', 'andhra pradesh', 'uttar pradesh', 'madhya pradesh', 
      'punjab', 'haryana', 'bihar', 'west bengal', 'odisha', 'assam', 'goa', 'india'
    ];
    
    const isStateMentioned = indianStates.some(s => lower.includes(s));
    if (isStateMentioned) {
      return { valid: true, normalized: `${trimmed}${trimmed.toLowerCase().includes('india') ? '' : ', India'}` };
    }

    // Allow user-entered locality
    return { valid: true, normalized: `${trimmed}, India` };
  };

  // Quick Select Matched Locality
  const handleSelectLocality = async (loc: LocalityItem) => {
    const address = `${loc.name} (${loc.pincode}), India`;
    setSelectedLocation(address);
    setSelectedCoords({ lat: loc.lat, lng: loc.lng });
    setSearchInput('');
    setErrorMessage(null);
    setSelectedSuccessToast(`Location set to ${loc.name}!`);
    setTimeout(() => setSelectedSuccessToast(null), 3000);
    await updateDeliveryAddress(address);
  };

  // Quick Select Nearby Locality Suggestion
  const handleSelectNearby = async (nearby: { name: string; fullAddress: string }) => {
    setSelectedLocation(nearby.fullAddress);
    setSearchInput('');
    setErrorMessage(null);
    setSelectedSuccessToast(`Location set to ${nearby.name}!`);
    setTimeout(() => setSelectedSuccessToast(null), 3000);
    await updateDeliveryAddress(nearby.fullAddress);
  };

  // Handle GPS "Use Current Location"
  const handleUseCurrentLocation = () => {
    if (!navigator.geolocation) {
      setErrorMessage('Geolocation is not supported by your browser.');
      return;
    }

    setIsLocating(true);
    setErrorMessage(null);

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;

        if (!isCoordinatesInIndia(latitude, longitude)) {
          setIsLocating(false);
          setErrorMessage(t('invalidLocation'));
          return;
        }

        // Find nearest city in India
        let closestCity = INDIAN_CITIES_DATABASE[0];
        let minDistance = Infinity;

        for (const city of INDIAN_CITIES_DATABASE) {
          const dist = Math.hypot(city.lat - latitude, city.lng - longitude);
          if (dist < minDistance) {
            minDistance = dist;
            closestCity = city;
          }
        }

        const addressString = `${closestCity.name} - ${closestCity.pincode}, India`;
        setSelectedCoords({ lat: latitude, lng: longitude });
        setSelectedLocation(addressString);
        await updateDeliveryAddress(addressString);
        setIsLocating(false);
      },
      (_error) => {
        setIsLocating(false);
        setErrorMessage('Unable to retrieve your GPS location. Please choose a city below or search your pincode.');
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  // Handle Search Submission
  const handleSearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchInput.trim()) return;

    setErrorMessage(null);

    const result = validateIndianAddress(searchInput);
    if (!result.valid) {
      setErrorMessage(t('invalidLocation'));
      return;
    }

    const finalAddress = result.normalized || `${searchInput.trim()}, India`;
    if (result.coords) {
      setSelectedCoords(result.coords);
    }
    setSelectedLocation(finalAddress);
    await updateDeliveryAddress(finalAddress);
    setSearchInput('');
  };

  // Handle direct selection from Minimal Satellite View
  const handleSelectFromSatellite = async (address: string, coords: { lat: number; lng: number }) => {
    setSelectedCoords(coords);
    setSelectedLocation(address);
    await updateDeliveryAddress(address);
    setSelectedSuccessToast(`Delivering to ${address.split(',')[0]} (Picked via Satellite)`);
    setTimeout(() => {
      setSelectedSuccessToast(null);
    }, 3500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-sm overflow-y-auto">
      <motion.div
        id="location-picker-modal"
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative w-full max-w-2xl bg-white dark:bg-zinc-900 rounded-3xl shadow-2xl border border-zinc-200 dark:border-zinc-800 p-4 sm:p-6 overflow-hidden text-zinc-900 dark:text-zinc-100 flex flex-col my-auto max-h-[95vh]"
      >
        {/* 1. Modal Header */}
        <div className="flex items-center justify-between pb-3 sm:pb-4 border-b border-zinc-100 dark:border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-emerald-600/10 text-emerald-600 dark:text-emerald-400">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-extrabold text-zinc-900 dark:text-white tracking-tight">
                {t('locationTitle')}
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                15-minute grocery delivery across India
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-2xl bg-zinc-100 dark:bg-zinc-800 text-zinc-500 hover:text-zinc-900 dark:hover:text-white transition cursor-pointer"
            aria-label="Close location modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Error notification */}
        <AnimatePresence>
          {errorMessage && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-3 p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/70 border border-rose-300 dark:border-rose-800 text-xs font-semibold text-rose-800 dark:text-rose-200 flex items-center gap-2"
            >
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMessage}</span>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="space-y-4 pt-3.5 overflow-y-auto pr-1">
          
          {/* 2. DIRECT LOCATION DISPLAY CARD (Shows location cleanly without 'Selected' button) */}
          <div className="p-3.5 rounded-2xl bg-emerald-50/90 dark:bg-emerald-950/50 border border-emerald-300 dark:border-emerald-700/60 flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-sm">
              <MapPin className="w-4 h-4" />
            </div>
            <div className="min-w-0 flex-1">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-800 dark:text-emerald-300 block">
                {selectedLocation ? 'Active Delivery Location:' : 'Delivery Location:'}
              </span>
              <span className="text-xs sm:text-sm font-bold text-zinc-900 dark:text-white truncate block">
                {selectedLocation || 'No delivery location selected yet'}
              </span>
            </div>
          </div>

          {/* 3. Primary Action: USE CURRENT LOCATION */}
          <button
            id="use-current-gps-location-btn"
            type="button"
            onClick={handleUseCurrentLocation}
            disabled={isLocating}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 active:scale-[0.98] text-white font-bold text-xs sm:text-sm shadow-md shadow-emerald-600/20 transition disabled:opacity-75 cursor-pointer"
          >
            <Navigation className={`w-4 h-4 ${isLocating ? 'animate-spin' : ''}`} />
            <span>{isLocating ? t('detectingLocation') : t('useCurrentLocation')}</span>
          </button>

          {/* 4. Indian Address / Pincode Search Bar with Live Nearby Suggestions */}
          <div className="relative space-y-2">
            <form onSubmit={handleSearchSubmit} className="relative">
              <div className="relative flex items-center">
                <Search className="w-4 h-4 text-emerald-600 dark:text-zinc-400 absolute left-3.5 pointer-events-none" />
                <input
                  id="location-search-input"
                  type="text"
                  value={searchInput}
                  onChange={(e) => {
                    setSearchInput(e.target.value);
                    if (errorMessage) setErrorMessage(null);
                  }}
                  placeholder="Type city, locality, pincode (e.g., Baner, Bandra, Koramangala)..."
                  className="w-full pl-10 pr-24 py-2.5 sm:py-3 rounded-2xl bg-zinc-50 dark:bg-zinc-800/80 border-2 border-emerald-500/40 focus:border-emerald-600 dark:border-zinc-700 dark:focus:border-emerald-500 text-xs sm:text-sm text-zinc-900 dark:text-white placeholder-zinc-400 outline-none transition shadow-2xs"
                />
                <button
                  type="submit"
                  className="absolute right-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow transition cursor-pointer"
                >
                  Set Location
                </button>
              </div>
            </form>

            {/* Success toast upon selection */}
            <AnimatePresence>
              {selectedSuccessToast && (
                <motion.div
                  initial={{ opacity: 0, y: -6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  className="p-2.5 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 border border-emerald-400 dark:border-emerald-700 text-emerald-800 dark:text-emerald-200 text-xs font-bold flex items-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{selectedSuccessToast}</span>
                </motion.div>
              )}
            </AnimatePresence>

            {/* LIVE AUTOCOMPLETE & NEARBY SUGGESTIONS AS USER TYPES */}
            {searchInput.trim().length >= 2 && (
              <motion.div
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-3 bg-white dark:bg-zinc-800/95 rounded-2xl border-2 border-emerald-500/40 shadow-xl space-y-3 max-h-72 overflow-y-auto"
              >
                {/* 4A: Exact / Matching Localities */}
                {searchSuggestions.matches.length > 0 && (
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-[11px] font-extrabold uppercase tracking-wider text-emerald-700 dark:text-emerald-400 px-1">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        Matching Locations ({searchSuggestions.matches.length}):
                      </span>
                    </div>
                    <div className="space-y-1">
                      {searchSuggestions.matches.slice(0, 5).map((loc) => (
                        <button
                          key={loc.id}
                          type="button"
                          onClick={() => handleSelectLocality(loc)}
                          className="w-full text-left p-2 rounded-xl hover:bg-emerald-50 dark:hover:bg-zinc-700/70 border border-transparent hover:border-emerald-200 dark:hover:border-zinc-600 transition flex items-center justify-between group cursor-pointer"
                        >
                          <div className="min-w-0">
                            <span className="text-xs sm:text-sm font-bold text-zinc-900 dark:text-white block group-hover:text-emerald-600 dark:group-hover:text-emerald-400 truncate">
                              {loc.name}
                            </span>
                            <span className="text-[11px] text-zinc-500 dark:text-zinc-400">
                              {loc.city}, {loc.state} • PIN: {loc.pincode}
                            </span>
                          </div>
                          <span className="text-[10px] font-bold px-2 py-1 rounded-lg bg-emerald-600 text-white shrink-0 shadow-2xs group-hover:scale-105 transition-transform">
                            Select
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* 4B: NEARBY LOCATIONS SUGGESTED NEAR SEARCH QUERY */}
                {searchSuggestions.nearbySuggestions.length > 0 && (
                  <div className="space-y-1.5 pt-2 border-t border-zinc-100 dark:border-zinc-700/70">
                    <div className="flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-wider text-amber-600 dark:text-amber-400 px-1">
                      <Compass className="w-3.5 h-3.5 animate-spin-slow" />
                      <span>Locations near "{searchInput.trim()}":</span>
                    </div>
                    <p className="text-[11px] text-zinc-500 dark:text-zinc-400 px-1">
                      Suggested neighboring hubs eligible for 15-min delivery:
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1">
                      {searchSuggestions.nearbySuggestions.slice(0, 8).map((nearby, idx) => (
                        <button
                          key={`${nearby.name}-${idx}`}
                          type="button"
                          onClick={() => handleSelectNearby(nearby)}
                          className="text-left p-2 rounded-xl bg-zinc-50 dark:bg-zinc-700/50 hover:bg-amber-50 dark:hover:bg-amber-950/40 border border-zinc-200 dark:border-zinc-700 hover:border-amber-300 dark:hover:border-amber-700 transition flex items-center justify-between group cursor-pointer"
                        >
                          <div className="min-w-0 pr-1">
                            <span className="text-xs font-bold text-zinc-800 dark:text-zinc-200 block group-hover:text-amber-600 dark:group-hover:text-amber-400 truncate">
                              {nearby.name}
                            </span>
                            <span className="text-[10px] text-zinc-500 dark:text-zinc-400 block truncate">
                              near {nearby.parentLocality} • {nearby.city}
                            </span>
                          </div>
                          <div className="text-right shrink-0">
                            <span className="text-[10px] font-extrabold text-amber-700 dark:text-amber-300 bg-amber-100 dark:bg-amber-900/60 px-1.5 py-0.5 rounded-md block">
                              {nearby.distance}
                            </span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* 4C: If no direct matches in local db, allow direct custom submission */}
                {searchSuggestions.matches.length === 0 && searchSuggestions.nearbySuggestions.length === 0 && (
                  <div className="p-3 text-center space-y-2 text-xs text-zinc-500 dark:text-zinc-400">
                    <p>No exact locality indexed for "{searchInput}".</p>
                    <button
                      type="button"
                      onClick={handleSearchSubmit}
                      className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs hover:bg-emerald-500 transition cursor-pointer shadow-xs"
                    >
                      Deliver to custom address "{searchInput}"
                    </button>
                  </div>
                )}
              </motion.div>
            )}
          </div>

          {/* 5. Minimal Satellite View with Direct Click-to-Select Location */}
          <div className="space-y-1.5 pt-1">
            <InteractiveSatelliteMap
              initialCoords={selectedCoords}
              selectedAddress={selectedLocation}
              onSelectLocation={handleSelectFromSatellite}
            />
          </div>
        </div>

        {/* 7. Modal Footer */}
        <div className="mt-4 pt-3 border-t border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
          <p className="text-[11px] text-zinc-500 dark:text-zinc-400 truncate max-w-[65%]">
            {selectedLocation ? `Delivering to: ${selectedLocation}` : 'No location selected'}
          </p>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition cursor-pointer"
          >
            Confirm & Done
          </button>
        </div>
      </motion.div>
    </div>
  );
};
