import React, { useState, useEffect } from 'react';
import { SignIn } from './SignIn';
import { SignUp } from './SignUp';
import { supabase } from '../supabaseClient.js';
import { ArrowLeft, ShoppingBag } from 'lucide-react';

interface LoginPageProps {
  initialMode?: 'signin' | 'signup';
}

export const LoginPage: React.FC<LoginPageProps> = ({ initialMode = 'signin' }) => {
  const [mode, setMode] = useState<'signin' | 'signup'>(initialMode);
  const [prefilledEmail, setPrefilledEmail] = useState<string>('');
  const [checking, setChecking] = useState(true);

  // If a real session already exists, redirect to home ("/")
  useEffect(() => {
    let isMounted = true;
    async function checkExistingSession() {
      try {
        const { data } = await supabase.auth.getSession();
        if (isMounted && data?.session) {
          window.location.href = '/';
          return;
        }
      } catch (e) {
        // Continue to show login form
      } finally {
        if (isMounted) {
          setChecking(false);
        }
      }
    }
    checkExistingSession();
    return () => {
      isMounted = false;
    };
  }, []);

  if (checking) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-zinc-50 dark:bg-zinc-950 p-6 space-y-4">
        <div className="w-10 h-10 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin" />
        <p className="text-xs font-bold uppercase tracking-wider text-zinc-500">
          Loading authentication...
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      {/* Return to store link */}
      <div className="max-w-md w-full mx-auto mb-6">
        <button
          onClick={() => {
            window.location.href = '/';
          }}
          className="inline-flex items-center gap-2 text-xs font-bold text-zinc-500 hover:text-emerald-600 transition cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Return to Store</span>
        </button>
      </div>

      <div className="max-w-md w-full mx-auto bg-white dark:bg-zinc-900 rounded-3xl p-6 sm:p-8 shadow-xl border border-zinc-200 dark:border-zinc-800">
        {mode === 'signin' ? (
          <SignIn
            initialEmail={prefilledEmail}
            onSwitchToSignUp={() => setMode('signup')}
          />
        ) : (
          <SignUp
            onSwitchToSignIn={(email) => {
              if (email) setPrefilledEmail(email);
              setMode('signin');
            }}
          />
        )}
      </div>

      <div className="mt-8 text-center text-xs text-zinc-400">
        SuperCart • Instant 15-Minute Grocery Delivery
      </div>
    </div>
  );
};
