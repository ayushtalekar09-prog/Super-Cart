import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  X, 
  Plus, 
  Minus, 
  ShoppingBag, 
  ArrowRight, 
  Tag, 
  MapPin, 
  CreditCard, 
  Banknote, 
  Wallet, 
  CheckCircle2, 
  AlertCircle,
  Sparkles,
  ShieldCheck,
  ExternalLink,
  RefreshCw
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { createSupabaseOrder as createOrder } from '../lib/supabase';
import { startRazorpayCheckout, createHostedPaymentLink, fetchLatestPaymentStatus } from '../lib/razorpay';
import { Order } from '../types';

interface CartDrawerProps {
  onOpenLocationModal: () => void;
  onOrderSuccess: (order: Order) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  onOpenLocationModal,
  onOrderSuccess
}) => {
  const { 
    isCartOpen, 
    setIsCartOpen, 
    items, 
    updateQuantity, 
    clearCart,
    subtotal, 
    discount, 
    deliveryFee, 
    tax, 
    total,
    appliedCoupon,
    applyCoupon,
    removeCoupon
  } = useCart();

  const { user, userProfile } = useAuth();
  const { t } = useLanguage();

  const [couponInput, setCouponInput] = useState('');
  const [couponFeedback, setCouponFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'Cash on Delivery' | 'Credit / Debit Card' | 'UPI / Net Banking' | 'Razorpay Hosted (rzp.io)'>('UPI / Net Banking');
  const [orderNotes, setOrderNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);
  const [paymentStatusCheck, setPaymentStatusCheck] = useState<{
    loading: boolean;
    data?: any;
    error?: string;
  } | null>(null);

  if (!isCartOpen) return null;

  const handleCheckLatestPayment = async () => {
    setPaymentStatusCheck({ loading: true });
    try {
      const data = await fetchLatestPaymentStatus();
      setPaymentStatusCheck({ loading: false, data });
    } catch (err: any) {
      setPaymentStatusCheck({ loading: false, error: err.message || 'Failed to check status' });
    }
  };

  const handleHostedCheckout = async (basePayload: Omit<Order, 'id' | 'createdAt'>) => {
    setIsSubmitting(true);
    setCheckoutError(null);
    try {
      localStorage.setItem('supercart_pending_order', JSON.stringify(basePayload));
      const link = await createHostedPaymentLink({
        amountInRupees: total,
        customer: {
          name: userProfile?.name || 'Valued Shopper',
          email: userProfile?.email || 'customer@supercart.com',
          phone: userProfile?.phone || '9876543210',
          address: basePayload.deliveryAddress,
        },
        notes: {
          order_notes: orderNotes.trim() || 'SuperCart Grocery Order',
        },
      });

      if (link && link.url) {
        window.location.href = link.url;
      } else {
        throw new Error('Could not generate hosted payment link');
      }
    } catch (err: any) {
      setIsSubmitting(false);
      setCheckoutError(err.message || 'Failed to generate hosted payment link.');
    }
  };

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput.trim()) return;
    const res = applyCoupon(couponInput);
    if (res.success) {
      setCouponFeedback({ type: 'success', text: res.message });
      setCouponInput('');
    } else {
      setCouponFeedback({ type: 'error', text: res.message });
    }
  };

  const handleCheckout = async () => {
    setCheckoutError(null);

    // Address check
    const currentAddress = userProfile?.address;
    if (!currentAddress) {
      setCheckoutError('Please select a delivery location in India before placing an order.');
      onOpenLocationModal();
      return;
    }

    // Cart check
    if (items.length === 0) {
      setCheckoutError(t('cartEmpty'));
      return;
    }

    setIsSubmitting(true);

    const basePayload: Omit<Order, 'id' | 'createdAt'> = {
      userId: user?.uid || 'shopper-guest-01',
      customerName: userProfile?.name || 'Valued Shopper',
      customerEmail: userProfile?.email || 'customer@supercart.com',
      customerPhone: userProfile?.phone || '+91 98765 43210',
      deliveryAddress: currentAddress,
      items,
      subtotal,
      discount,
      discountCode: appliedCoupon || undefined,
      deliveryFee,
      tax,
      total,
      paymentMethod,
      status: 'Placed',
      notes: orderNotes.trim() || undefined
    };

    const finalizeOrderPlacement = async (completedPayload: Omit<Order, 'id' | 'createdAt'>) => {
      try {
        const orderId = await createOrder(completedPayload);

        try {
          confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 }
          });
        } catch (err) {}

        const fullCreatedOrder: Order = {
          ...completedPayload,
          id: orderId,
          createdAt: new Date().toISOString(),
          estimatedDeliveryTime: new Date(Date.now() + 20 * 60 * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          driverName: 'Ramesh Patil',
          driverPhone: '+91 98230 45678',
          driverVehicle: 'SuperCart Electric Express (MH-12-EK-4040)'
        };

        clearCart();
        setIsCartOpen(false);
        onOrderSuccess(fullCreatedOrder);
      } catch (err: any) {
        console.error('Checkout error:', err);
        setCheckoutError(err.message || 'Could not place order. Please try again.');
      } finally {
        setIsSubmitting(false);
      }
    };

    // When clicking Place Order:
    if (paymentMethod === 'Razorpay Hosted (rzp.io)') {
      await handleHostedCheckout(basePayload);
      return;
    }

    if (paymentMethod !== 'Cash on Delivery') {
      try {
        try {
          localStorage.setItem('supercart_pending_order', JSON.stringify(basePayload));
        } catch (e) {}

        await startRazorpayCheckout({
          amountInRupees: total,
          customer: {
            name: userProfile?.name || 'Valued Shopper',
            email: userProfile?.email || 'customer@supercart.com',
            phone: userProfile?.phone || '9876543210',
            address: currentAddress,
          },
          notes: {
            order_notes: orderNotes.trim() || 'SuperCart Grocery Order',
            payment_option: paymentMethod,
          },
          onSuccess: async (paymentResult) => {
            // Payment succeeded and signature verified on server: now place order
            try {
              localStorage.removeItem('supercart_pending_order');
            } catch (e) {}
            const paidOrderPayload: Omit<Order, 'id' | 'createdAt'> = {
              ...basePayload,
              razorpayPaymentId: paymentResult.payment_id,
              razorpayOrderId: paymentResult.order_id,
            };
            await finalizeOrderPlacement(paidOrderPayload);
          },
          onError: (paymentError) => {
            console.error('Razorpay payment error:', paymentError);
            setIsSubmitting(false);
            setCheckoutError(paymentError.message || 'Payment failed. You can retry or choose another payment method.');
          },
          onDismiss: () => {
            setIsSubmitting(false);
            setCheckoutError('Payment cancelled. Your cart items are preserved so you can checkout whenever ready.');
          },
        });
      } catch (err: any) {
        setIsSubmitting(false);
        setCheckoutError(err.message || 'Could not initiate Razorpay checkout.');
      }
    } else {
      // Cash on Delivery
      await finalizeOrderPlacement(basePayload);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/70 backdrop-blur-sm">
      <div className="absolute inset-0" onClick={() => setIsCartOpen(false)} />

      <motion.div
        id="cart-drawer-panel"
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'spring', damping: 25, stiffness: 220 }}
        className="absolute inset-y-0 right-0 max-w-full flex pl-0 sm:pl-8"
      >
        <div className="w-screen max-w-full sm:max-w-md bg-white dark:bg-zinc-900 shadow-2xl flex flex-col border-l border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-zinc-100">
          
          {/* Top Cart Header */}
          <div className="p-4 sm:p-5 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between bg-zinc-50 dark:bg-zinc-900">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-2xl bg-emerald-600 text-white shadow-md shadow-emerald-600/20">
                <ShoppingBag className="w-5 h-5 text-amber-300" />
              </div>
              <div>
                <h3 className="font-extrabold text-base text-zinc-900 dark:text-white">
                  {t('yourCart')}
                </h3>
                <p className="text-xs text-zinc-500 dark:text-zinc-300">
                  {items.length} {items.length === 1 ? 'item' : 'items'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {items.length > 0 && (
                <button
                  id="clear-cart-btn"
                  onClick={clearCart}
                  className="text-xs text-zinc-500 hover:text-red-500 dark:text-zinc-400 dark:hover:text-red-400 font-semibold transition px-2 py-1 cursor-pointer"
                >
                  Clear
                </button>
              )}
              <button
                id="close-cart-drawer-btn"
                onClick={() => setIsCartOpen(false)}
                className="p-2 rounded-full text-zinc-500 hover:text-zinc-900 dark:text-zinc-300 dark:hover:text-white hover:bg-zinc-200 dark:hover:bg-zinc-800 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Cart Content */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5 bg-white dark:bg-zinc-900">
            
            {/* Delivery address banner */}
            <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-700/60 flex items-center justify-between">
              <div className="flex items-center gap-2.5 min-w-0">
                <MapPin className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <div className="min-w-0">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 dark:text-emerald-300 block">
                    {t('deliverTo')}:
                  </span>
                  <span className="text-xs font-bold text-zinc-900 dark:text-white truncate block">
                    {userProfile?.address || t('noLocationSelected')}
                  </span>
                </div>
              </div>
              <button
                id="change-address-in-cart-btn"
                onClick={onOpenLocationModal}
                className="text-xs font-bold text-emerald-700 dark:text-emerald-300 underline shrink-0 hover:text-emerald-800 dark:hover:text-emerald-200 ml-2 cursor-pointer"
              >
                {userProfile?.address ? 'Change' : 'Set'}
              </button>
            </div>

            {/* Error message and Immediate Resolution Actions */}
            {checkoutError && (
              <div className="p-3.5 rounded-2xl bg-red-50 dark:bg-red-950/70 border border-red-300 dark:border-red-800 text-xs space-y-2.5">
                <div className="flex items-start gap-2 text-red-800 dark:text-red-200 font-semibold">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
                  <span>{checkoutError}</span>
                </div>

                {/* Instant Resolution Buttons */}
                <div className="pt-2 border-t border-red-200 dark:border-red-900/60 flex flex-col gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setPaymentMethod('Razorpay Hosted (rzp.io)');
                      setCheckoutError(null);
                    }}
                    className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition cursor-pointer"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Switch to Razorpay Hosted (rzp.io) & Pay</span>
                  </button>
                  
                  <button
                    type="button"
                    onClick={handleCheckLatestPayment}
                    disabled={paymentStatusCheck?.loading}
                    className="w-full py-2 px-3 rounded-xl bg-white dark:bg-zinc-800 hover:bg-zinc-100 dark:hover:bg-zinc-700 text-zinc-800 dark:text-zinc-200 border border-zinc-300 dark:border-zinc-700 font-semibold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${paymentStatusCheck?.loading ? 'animate-spin' : ''}`} />
                    <span>Check Recent Payment Status with Razorpay</span>
                  </button>
                </div>

                {/* Real-Time Payment Status Result from Razorpay */}
                {paymentStatusCheck && (
                  <div className="p-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-[11px] text-zinc-700 dark:text-zinc-300 space-y-1">
                    {paymentStatusCheck.loading ? (
                      <div className="flex items-center gap-1.5 text-zinc-500">
                        <RefreshCw className="w-3 h-3 animate-spin" />
                        <span>Querying Razorpay servers...</span>
                      </div>
                    ) : paymentStatusCheck.data && paymentStatusCheck.data.found ? (
                      <div>
                        <div className="font-bold text-zinc-900 dark:text-white flex justify-between items-center mb-1">
                          <span>ID: {paymentStatusCheck.data.id}</span>
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${paymentStatusCheck.data.status === 'captured' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}`}>
                            {paymentStatusCheck.data.status}
                          </span>
                        </div>
                        {paymentStatusCheck.data.status === 'failed' && (
                          <div className="space-y-1 text-zinc-600 dark:text-zinc-400">
                            <p>
                              Razorpay Reason: <strong>{paymentStatusCheck.data.error_description || 'Website not matching registered domain'}</strong>
                            </p>
                            <p className="text-emerald-700 dark:text-emerald-400 font-medium bg-emerald-50 dark:bg-emerald-950/60 p-1.5 rounded-lg border border-emerald-200 dark:border-emerald-800">
                              Auto-Refund Guarantee: Because Razorpay marked this payment as <strong>FAILED</strong>, your bank/UPI automatically reverses the debited amount back to your account.
                            </p>
                          </div>
                        )}
                      </div>
                    ) : (
                      <p className="text-zinc-500">No recent payment attempt found on Razorpay.</p>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Items List without delete button */}
            {items.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center text-zinc-500 dark:text-zinc-400">
                <div className="w-16 h-16 rounded-full bg-zinc-100 dark:bg-zinc-800 flex items-center justify-center mb-3">
                  <ShoppingBag className="w-8 h-8 text-zinc-400 dark:text-zinc-500" />
                </div>
                <h4 className="font-bold text-zinc-900 dark:text-zinc-100 text-sm">
                  {t('cartEmpty')}
                </h4>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1 max-w-[220px]">
                  {t('emptyCartPrompt')}
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                <span className="text-xs font-bold uppercase tracking-wider text-zinc-600 dark:text-zinc-300 block">
                  {t('itemDetails')} ({items.length})
                </span>
                
                {items.map(({ product, quantity }) => (
                  <div
                    key={product.id}
                    className="p-3 rounded-2xl bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700/80 flex items-center gap-3 shadow-xs"
                  >
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-14 h-14 rounded-xl object-cover bg-white dark:bg-zinc-700 shrink-0"
                      referrerPolicy="no-referrer"
                    />

                    <div className="flex-1 min-w-0">
                      <h4 className="font-extrabold text-xs text-zinc-900 dark:text-zinc-100 truncate">
                        {product.name}
                      </h4>
                      <p className="text-[11px] text-zinc-500 dark:text-zinc-400 font-mono">
                        ₹{product.price.toFixed(2)} / {product.unit}
                      </p>
                      <span className="font-black text-xs text-emerald-600 dark:text-emerald-400">
                        ₹{(product.price * quantity).toFixed(2)}
                      </span>
                    </div>

                    {/* Quantity controls only (Delete button removed per explicit user requirement) */}
                    <div className="flex items-center gap-1 bg-white dark:bg-zinc-900 rounded-xl p-1 border border-zinc-200 dark:border-zinc-700 shadow-sm">
                      <button
                        onClick={() => updateQuantity(product.id, quantity - 1)}
                        className="w-7 h-7 flex items-center justify-center text-zinc-700 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg transition active:scale-90 cursor-pointer"
                        title="Reduce quantity"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-6 text-center text-xs font-black font-mono text-zinc-900 dark:text-zinc-100">
                        {quantity}
                      </span>
                      <button
                        onClick={() => updateQuantity(product.id, quantity + 1)}
                        disabled={quantity >= product.stock}
                        className="w-7 h-7 flex items-center justify-center text-zinc-700 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg transition active:scale-90 disabled:opacity-40 cursor-pointer"
                        title="Increase quantity"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Coupon Code Section */}
            {items.length > 0 && (
              <div className="p-3.5 rounded-2xl bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700/80 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-zinc-800 dark:text-zinc-200 flex items-center gap-1.5">
                    <Tag className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    <span>Apply Savings Coupon</span>
                  </span>
                  {appliedCoupon && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300">
                      {appliedCoupon}
                    </span>
                  )}
                </div>

                {appliedCoupon ? (
                  <div className="flex items-center justify-between p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 text-xs">
                    <span className="font-bold text-emerald-700 dark:text-emerald-300">
                      {t('appliedCoupon')}: -₹{discount.toFixed(2)}
                    </span>
                    <button
                      type="button"
                      onClick={removeCoupon}
                      className="text-xs text-rose-600 dark:text-rose-400 hover:underline font-bold"
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleApplyCoupon} className="flex gap-2">
                    <input
                      type="text"
                      value={couponInput}
                      onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                      placeholder="e.g. FRESH10, HARVEST20"
                      className="flex-1 px-3 py-2 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 text-xs font-bold text-zinc-900 dark:text-white uppercase placeholder:normal-case placeholder:font-normal placeholder-zinc-400 outline-none focus:border-emerald-500"
                    />
                    <button
                      type="submit"
                      className="px-3.5 py-2 rounded-xl bg-zinc-900 dark:bg-zinc-700 hover:bg-zinc-800 text-white text-xs font-bold transition"
                    >
                      Apply
                    </button>
                  </form>
                )}

                {couponFeedback && (
                  <p className={`text-[11px] font-semibold ${couponFeedback.type === 'success' ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-500 dark:text-red-400'}`}>
                    {couponFeedback.text}
                  </p>
                )}
              </div>
            )}

            {/* Payment Method Selector */}
            {items.length > 0 && (
              <div className="p-3.5 rounded-2xl bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700/80 space-y-2.5">
                <span className="text-xs font-bold text-zinc-800 dark:text-zinc-200 block">
                  {t('paymentMethod')}
                </span>
                
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'UPI / Net Banking', label: t('upiNetBanking'), icon: Wallet },
                    { id: 'Credit / Debit Card', label: t('cardPayment'), icon: CreditCard },
                    { id: 'Razorpay Hosted (rzp.io)', label: 'Razorpay Hosted (rzp.io)', icon: ExternalLink },
                    { id: 'Cash on Delivery', label: t('cashOnDelivery'), icon: Banknote },
                  ].map((method) => {
                    const Icon = method.icon;
                    const isSelected = paymentMethod === method.id;
                    return (
                      <button
                        key={method.id}
                        type="button"
                        onClick={() => setPaymentMethod(method.id as any)}
                        className={`p-2.5 rounded-xl border text-left flex items-center gap-2 transition cursor-pointer ${
                          isSelected
                            ? 'bg-emerald-50 dark:bg-emerald-950/70 border-emerald-500 text-emerald-800 dark:text-emerald-300 font-bold shadow-xs'
                            : 'bg-white dark:bg-zinc-900 border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800'
                        }`}
                      >
                        <Icon className={`w-4 h-4 ${isSelected ? 'text-emerald-600 dark:text-emerald-400' : 'text-zinc-400'}`} />
                        <span className="text-[11px] leading-tight line-clamp-1">{method.label}</span>
                      </button>
                    );
                  })}
                </div>

                <div className="flex items-center gap-1.5 pt-1 text-[11px] text-zinc-500 dark:text-zinc-400">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <span>Secured by Razorpay • UPI, Cards & Net Banking</span>
                </div>
              </div>
            )}

            {/* Bill Summary - High contrast dark mode styling */}
            {items.length > 0 && (
              <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-800/90 border border-zinc-200 dark:border-zinc-700 space-y-2.5">
                <span className="text-xs font-extrabold uppercase tracking-wider text-zinc-700 dark:text-zinc-200 block">
                  {t('bills')}
                </span>
                
                <div className="flex justify-between text-xs text-zinc-700 dark:text-zinc-300">
                  <span>{t('subtotal')}</span>
                  <span className="font-mono font-bold text-zinc-900 dark:text-white">₹{subtotal.toFixed(2)}</span>
                </div>

                {discount > 0 && (
                  <div className="flex justify-between text-xs text-emerald-600 dark:text-emerald-400 font-bold">
                    <span>{t('discount')}</span>
                    <span className="font-mono">-₹{discount.toFixed(2)}</span>
                  </div>
                )}

                <div className="flex justify-between text-xs text-zinc-700 dark:text-zinc-300">
                  <span>{t('deliveryCharge')} (3%)</span>
                  <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                    {deliveryFee === 0 ? t('freeDelivery') : `₹${deliveryFee.toFixed(2)}`}
                  </span>
                </div>

                <div className="flex justify-between text-xs text-zinc-700 dark:text-zinc-300">
                  <span>{t('taxAndFees')} (5% GST)</span>
                  <span className="font-mono font-bold text-zinc-900 dark:text-white">₹{tax.toFixed(2)}</span>
                </div>

                <div className="pt-2 border-t border-zinc-200 dark:border-zinc-700 flex justify-between items-baseline">
                  <span className="text-sm font-extrabold text-zinc-900 dark:text-white">{t('totalToPay')}</span>
                  <span className="text-lg font-black text-emerald-600 dark:text-emerald-400 font-mono">
                    ₹{total.toFixed(2)}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Bottom Checkout CTA */}
          {items.length > 0 && (
            <div className="p-4 sm:p-5 border-t border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900">
              <button
                id="place-order-btn"
                type="button"
                onClick={handleCheckout}
                disabled={isSubmitting}
                className="w-full py-3.5 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 active:scale-[0.98] text-white font-extrabold text-sm shadow-lg shadow-emerald-600/30 flex items-center justify-between transition disabled:opacity-75 cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  {paymentMethod !== 'Cash on Delivery' && (
                    <ShieldCheck className="w-4 h-4 text-emerald-200" />
                  )}
                  <span>
                    {isSubmitting
                      ? 'Processing Payment...'
                      : paymentMethod === 'Razorpay Hosted (rzp.io)'
                      ? 'Pay on Razorpay (rzp.io)'
                      : paymentMethod !== 'Cash on Delivery'
                      ? 'Place Order • Pay with Razorpay'
                      : t('placeOrder')}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 font-mono">
                  <span>₹{total.toFixed(2)}</span>
                  <ArrowRight className="w-4 h-4" />
                </div>
              </button>
            </div>
          )}

        </div>
      </motion.div>
    </div>
  );
};
