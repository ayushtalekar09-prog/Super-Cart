import React, { useState, useEffect } from 'react';
import { Mail, Lock, Eye, EyeOff, ArrowRight, AlertCircle, ShoppingBag, CheckCircle2 } from 'lucide-react';
import { supabase } from '../supabaseClient.js';

interface SignInProps {
  initialEmail?: string;
  onSwitchToSignUp?: () => void;
  onForgotPassword?: () => void;
}

export const SignIn: React.FC<SignInProps> = ({
  initialEmail = '',
  onSwitchToSignUp,
  onForgotPassword,
}) => {
  // Retrieve initial email from prop, URL search param (?email=...), or sessionStorage
  const [email, setEmail] = useState<string>(() => {
    if (initialEmail) return initialEmail;
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const urlEmail = params.get('email');
      if (urlEmail) return urlEmail;
      try {
        const stored = sessionStorage.getItem('supercart_signup_email');
        if (stored) return stored;
      } catch (e) {}
    }
    return '';
  });

  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Check if user came from a successful signup
  const [successMessage, setSuccessMessage] = useState<string | null>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('verified') === 'true') {
        return 'Email verified successfully! You can now sign in to your SuperCart account.';
      }
      if (params.get('signup') === 'success') {
        return 'Your account has been created. Please check your email and click the confirmation link before logging in.';
      }
      try {
        if (sessionStorage.getItem('supercart_signup_success') === 'true') {
          sessionStorage.removeItem('supercart_signup_success');
          return 'Your account has been created. Please check your email and verify your address before logging in.';
        }
      } catch (e) {}
    }
    return null;
  });

  // Keep email and success message in sync if initialEmail is passed or updated
  useEffect(() => {
    if (initialEmail) {
      setEmail(initialEmail);
      setSuccessMessage(
        'Your account has been created. Please check your email and verify your address before logging in.'
      );
    }
  }, [initialEmail]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });

      if (signInError) {
        setError(signInError.message);
        return;
      }

      // Only redirect when a real session exists after login
      if (data?.session) {
        // Clear any stored signup email/state on successful login
        try {
          sessionStorage.removeItem('supercart_signup_email');
          sessionStorage.removeItem('supercart_signup_success');
        } catch (e) {}
        window.location.href = '/';
      } else {
        setError('No active session found. Please check your credentials or confirm your email.');
      }
    } catch (err: any) {
      setError(err?.message || 'An unexpected error occurred during sign in.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto space-y-5">
      {/* Header Branding */}
      <div className="text-center space-y-1">
        <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-emerald-600 text-white shadow-md shadow-emerald-600/20 mb-1">
          <ShoppingBag className="w-6 h-6 text-amber-300" />
        </div>
        <h2 className="text-2xl font-black tracking-tight text-zinc-900 dark:text-white">
          Welcome to SuperCart
        </h2>
        <p className="text-xs text-zinc-500 dark:text-zinc-400">
          15-Minute Grocery Delivery • Fresh Daily
        </p>
      </div>

      {/* Success banner ABOVE the form if coming from a successful signup */}
      {successMessage && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 flex items-start gap-2.5 text-xs text-emerald-800 dark:text-emerald-200 shadow-xs">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
          <span className="font-semibold leading-relaxed">{successMessage}</span>
        </div>
      )}

      {/* Sign In Form */}
      <form onSubmit={handleSubmit} className="space-y-3.5" autoComplete="off">
        {/* Email Address */}
        <div>
          <label className="block text-[11px] font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Email address
          </label>
          <div className="relative">
            <Mail className="w-4 h-4 text-zinc-400 absolute left-4 top-3.5" />
            <input
              id="signin-email"
              type="email"
              required
              autoComplete="email"
              placeholder="name@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full pl-11 pr-4 py-3 rounded-2xl border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800/70 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 transition text-zinc-900 dark:text-zinc-100"
              autoFocus
            />
          </div>
        </div>

        {/* Password */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="text-[11px] font-bold uppercase tracking-wider text-zinc-500">
              Password
            </label>
            {onForgotPassword && (
              <button
                type="button"
                onClick={onForgotPassword}
                className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
              >
                Forgot password?
              </button>
            )}
          </div>
          <div className="relative">
            <Lock className="w-4 h-4 text-zinc-400 absolute left-4 top-3.5" />
            <input
              id="signin-password"
              type={showPassword ? 'text' : 'password'}
              required
              autoComplete="current-password"
              minLength={6}
              placeholder="At least 6 characters"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full pl-11 pr-11 py-3 rounded-2xl border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800/70 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 transition text-zinc-900 dark:text-zinc-100"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-3.5 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Submit Button */}
        <button
          id="signin-submit-btn"
          type="submit"
          disabled={loading}
          className="w-full mt-2 py-3.5 px-6 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white font-black text-sm tracking-wide shadow-lg shadow-emerald-600/25 active:scale-[0.98] transition flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer"
        >
          {loading ? (
            <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin" />
          ) : (
            <>
              <span>Sign In to SuperCart</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>

        {/* Simple error handling under the form */}
        {error && (
          <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 flex items-start gap-2 text-xs text-rose-700 dark:text-rose-300">
            <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
            <span className="font-medium">{error}</span>
          </div>
        )}
      </form>

      {/* Switch to Sign Up */}
      {onSwitchToSignUp && (
        <div className="text-center pt-2 border-t border-zinc-100 dark:border-zinc-800">
          <p className="text-xs text-zinc-500">
            New to SuperCart?{' '}
            <button
              type="button"
              onClick={onSwitchToSignUp}
              className="font-bold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer ml-1"
            >
              Create an account
            </button>
          </p>
        </div>
      )}
    </div>
  );
};
