import React, { useState } from 'react';
import { Mail, Lock, User, Eye, EyeOff, ArrowRight, AlertCircle, ShoppingBag } from 'lucide-react';
import { supabase } from '../supabaseClient.js';

interface SignUpProps {
  onSwitchToSignIn?: (email?: string) => void;
}

export const SignUp: React.FC<SignUpProps> = ({ onSwitchToSignIn }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const userEmail = email.trim();

    try {
      const { data, error: signUpError } = await supabase.auth.signUp({
        email: userEmail,
        password,
        options: {
          data: {
            name: name.trim(),
          },
          emailRedirectTo: typeof window !== 'undefined' ? `${window.location.origin}/login?verified=true` : undefined,
        },
      });

      if (signUpError) {
        setError(signUpError.message);
        return;
      }

      // Do NOT auto-login. If Supabase generated an active session, sign out immediately
      if (data?.session) {
        await supabase.auth.signOut();
      }

      // Store in sessionStorage so Sign In can pre-fill email and show success message
      try {
        sessionStorage.setItem('supercart_signup_email', userEmail);
        sessionStorage.setItem('supercart_signup_success', 'true');
      } catch (e) {}

      // Update URL query parameters for clean state sharing and direct redirects
      try {
        const url = new URL(window.location.href);
        url.pathname = '/login';
        url.searchParams.set('email', userEmail);
        url.searchParams.set('signup', 'success');
        window.history.replaceState({}, '', url.toString());
      } catch (e) {}

      // Redirect user to the Sign In page with the pre-filled email
      if (onSwitchToSignIn) {
        onSwitchToSignIn(userEmail);
      } else {
        window.location.href = `/login?email=${encodeURIComponent(userEmail)}&signup=success`;
      }
    } catch (err: any) {
      setError(err?.message || 'An unexpected error occurred during sign up.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto space-y-5">
      {/* Header Branding */}
      <div className="text-center space-y-1">
        <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-emerald-600 text-white shadow-md shadow-emerald-600/20 mb-1">
          <ShoppingBag className="w-6 h-6 text-amber-300" />
        </div>
        <h2 className="text-2xl font-black tracking-tight text-zinc-900 dark:text-white">
          Create SuperCart Account
        </h2>
        <p className="text-xs text-zinc-500 dark:text-zinc-400">
          15-Minute Grocery Delivery • Fresh Daily
        </p>
      </div>

      {/* Sign Up Form */}
      <form onSubmit={handleSubmit} className="space-y-3.5" autoComplete="off">
        {/* Full Name */}
        <div>
          <label className="block text-[11px] font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Full Name
          </label>
          <div className="relative">
            <User className="w-4 h-4 text-zinc-400 absolute left-4 top-3.5" />
            <input
              id="signup-name"
              type="text"
              required
              autoComplete="name"
              placeholder="Your Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full pl-11 pr-4 py-3 rounded-2xl border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800/70 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 transition text-zinc-900 dark:text-zinc-100"
              autoFocus
            />
          </div>
        </div>

        {/* Email Address */}
        <div>
          <label className="block text-[11px] font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Email address
          </label>
          <div className="relative">
            <Mail className="w-4 h-4 text-zinc-400 absolute left-4 top-3.5" />
            <input
              id="signup-email"
              type="email"
              required
              autoComplete="email"
              placeholder="name@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full pl-11 pr-4 py-3 rounded-2xl border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800/70 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 transition text-zinc-900 dark:text-zinc-100"
            />
          </div>
        </div>

        {/* Password */}
        <div>
          <label className="block text-[11px] font-bold uppercase tracking-wider text-zinc-500 mb-1">
            Password
          </label>
          <div className="relative">
            <Lock className="w-4 h-4 text-zinc-400 absolute left-4 top-3.5" />
            <input
              id="signup-password"
              type={showPassword ? 'text' : 'password'}
              required
              autoComplete="new-password"
              minLength={6}
              placeholder="At least 6 characters"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full pl-11 pr-11 py-3 rounded-2xl border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800/70 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 transition text-zinc-900 dark:text-zinc-100"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-3.5 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Submit Button */}
        <button
          id="signup-submit-btn"
          type="submit"
          disabled={loading}
          className="w-full mt-2 py-3.5 px-6 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white font-black text-sm tracking-wide shadow-lg shadow-emerald-600/25 active:scale-[0.98] transition flex items-center justify-center gap-2 disabled:opacity-60 cursor-pointer"
        >
          {loading ? (
            <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin" />
          ) : (
            <>
              <span>Create SuperCart Account</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>

        {/* Simple error handling under the form */}
        {error && (
          <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 flex items-start gap-2 text-xs text-rose-700 dark:text-rose-300">
            <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
            <span className="font-medium">{error}</span>
          </div>
        )}
      </form>

      {/* Switch to Sign In */}
      {onSwitchToSignIn && (
        <div className="text-center pt-2 border-t border-zinc-100 dark:border-zinc-800">
          <p className="text-xs text-zinc-500">
            Already have an account?{' '}
            <button
              type="button"
              onClick={() => onSwitchToSignIn()}
              className="font-bold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer ml-1"
            >
              Sign In
            </button>
          </p>
        </div>
      )}
    </div>
  );
};
