-- ==============================================================================
-- SuperCart Supabase Schema & Realtime Setup
-- Paste this script into your Supabase SQL Editor:
-- https://supabase.com/dashboard/project/wavkucsbhhcgnypntglt/sql
-- ==============================================================================

-- 1. Products Table
CREATE TABLE IF NOT EXISTS public.products (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  price NUMERIC NOT NULL,
  original_price NUMERIC,
  stock INTEGER DEFAULT 0,
  unit TEXT DEFAULT 'pack',
  image TEXT,
  description TEXT,
  rating NUMERIC DEFAULT 4.5,
  review_count INTEGER DEFAULT 12,
  badge TEXT,
  is_featured BOOLEAN DEFAULT FALSE,
  organic BOOLEAN DEFAULT FALSE,
  season TEXT,
  origin TEXT,
  ingredients JSONB DEFAULT '[]'::jsonb,
  nutrition JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Orders Table
CREATE TABLE IF NOT EXISTS public.orders (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  customer_name TEXT,
  customer_email TEXT,
  customer_phone TEXT,
  delivery_address TEXT,
  items JSONB NOT NULL DEFAULT '[]'::jsonb,
  subtotal NUMERIC NOT NULL DEFAULT 0,
  discount NUMERIC DEFAULT 0,
  discount_code TEXT,
  delivery_fee NUMERIC DEFAULT 0,
  tax NUMERIC DEFAULT 0,
  total NUMERIC NOT NULL DEFAULT 0,
  payment_method TEXT DEFAULT 'UPI / Net Banking',
  status TEXT DEFAULT 'Placed',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  estimated_delivery_time TEXT,
  driver_name TEXT,
  driver_phone TEXT,
  driver_vehicle TEXT,
  notes TEXT
);

-- 3. Profiles Table
CREATE TABLE IF NOT EXISTS public.profiles (
  id TEXT PRIMARY KEY,
  uid TEXT,
  email TEXT,
  name TEXT,
  phone TEXT,
  phone_number TEXT,
  phone_verified BOOLEAN DEFAULT FALSE,
  email_verified BOOLEAN DEFAULT FALSE,
  gender TEXT DEFAULT 'Prefer not to say',
  photo_url TEXT,
  avatar TEXT,
  address TEXT,
  saved_addresses JSONB DEFAULT '[]'::jsonb,
  role TEXT DEFAULT 'user',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Enable Row Level Security (RLS)
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- 5. Drop existing policies to allow re-running without conflicts
DROP POLICY IF EXISTS "Public read products" ON public.products;
DROP POLICY IF EXISTS "Anon insert products" ON public.products;
DROP POLICY IF EXISTS "Anon update products" ON public.products;
DROP POLICY IF EXISTS "Anon delete products" ON public.products;

DROP POLICY IF EXISTS "Public read orders" ON public.orders;
DROP POLICY IF EXISTS "Anon insert orders" ON public.orders;
DROP POLICY IF EXISTS "Anon update orders" ON public.orders;

DROP POLICY IF EXISTS "Public read profiles" ON public.profiles;
DROP POLICY IF EXISTS "Anon insert profiles" ON public.profiles;
DROP POLICY IF EXISTS "Anon update profiles" ON public.profiles;

-- 6. Recreate Policies for full web access
CREATE POLICY "Public read products" ON public.products FOR SELECT USING (true);
CREATE POLICY "Anon insert products" ON public.products FOR INSERT WITH CHECK (true);
CREATE POLICY "Anon update products" ON public.products FOR UPDATE USING (true);
CREATE POLICY "Anon delete products" ON public.products FOR DELETE USING (true);

CREATE POLICY "Public read orders" ON public.orders FOR SELECT USING (true);
CREATE POLICY "Anon insert orders" ON public.orders FOR INSERT WITH CHECK (true);
CREATE POLICY "Anon update orders" ON public.orders FOR UPDATE USING (true);

CREATE POLICY "Public read profiles" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Anon insert profiles" ON public.profiles FOR INSERT WITH CHECK (true);
CREATE POLICY "Anon update profiles" ON public.profiles FOR UPDATE USING (true);

-- 7. Enable Realtime Publications (safely)
DO $$
BEGIN
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.products;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.orders;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;

  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;
END $$;
