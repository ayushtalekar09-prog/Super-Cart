import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import crypto from 'crypto';
import Razorpay from 'razorpay';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';

dotenv.config({ override: true });

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = parseInt(process.env.PORT || '3000', 10);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Initialize Razorpay SDK using server-side credentials
const getRazorpayClient = () => {
  const key_id = process.env.RAZORPAY_KEY_ID || process.env.VITE_RAZORPAY_KEY_ID;
  const key_secret = process.env.RAZORPAY_KEY_SECRET;

  if (!key_id || !key_secret) {
    throw new Error('Missing RAZORPAY_KEY_ID or RAZORPAY_KEY_SECRET in server environment');
  }

  return new Razorpay({
    key_id,
    key_secret,
  });
};

// --------------------------------------------------------------------------
// STEP 1: BACKEND - Create Order
// Endpoint: POST /api/create-order
// Request: { amount (paise), currency, receipt, notes }
// Return: { order_id, amount, currency, key_id }
// Minimum amount: 100 paise
// --------------------------------------------------------------------------
app.post(['/api/create-order', '/api/razorpay/create-order'], async (req, res) => {
  try {
    const { amount, currency = 'INR', receipt, notes } = req.body;

    const parsedAmount = Math.round(Number(amount));
    // Validate minimum amount is 100 paise (₹1.00)
    if (isNaN(parsedAmount) || parsedAmount < 100) {
      return res.status(400).json({
        error: 'Invalid amount. Minimum amount is 100 paise (₹1.00).',
      });
    }

    const key_id = process.env.RAZORPAY_KEY_ID || process.env.VITE_RAZORPAY_KEY_ID;
    const key_secret = process.env.RAZORPAY_KEY_SECRET;

    if (!key_id || !key_secret) {
      return res.status(401).json({
        error: 'Razorpay authentication failed: Credentials not configured on server.',
      });
    }

    const razorpay = getRazorpayClient();

    const options = {
      amount: parsedAmount,
      currency: currency || 'INR',
      receipt: receipt || `rcpt_${Date.now()}_${Math.floor(100 + Math.random() * 900)}`,
      notes: notes || {},
    };

    const order = await razorpay.orders.create(options);

    return res.status(200).json({
      order_id: order.id,
      amount: order.amount,
      currency: order.currency,
      key_id: key_id,
    });
  } catch (error: any) {
    console.error('Razorpay create-order error:', error);
    const statusCode = error?.statusCode || 500;
    return res.status(statusCode).json({
      error: error?.message || 'Failed to create Razorpay order',
      details: error?.error || undefined,
    });
  }
});

// --------------------------------------------------------------------------
// STEP 3: BACKEND - Verify Signature
// Endpoint: POST /api/verify-payment
// Algorithm: HMAC-SHA256(order_id + "|" + payment_id, KEY_SECRET)
// Compare generated signature with razorpay_signature
// --------------------------------------------------------------------------
app.post(['/api/verify-payment', '/api/razorpay/verify-payment'], (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;

    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      return res.status(400).json({
        status: 'failed',
        error: 'Missing required parameters: razorpay_order_id, razorpay_payment_id, and razorpay_signature are required.',
      });
    }

    const key_secret = process.env.RAZORPAY_KEY_SECRET;
    if (!key_secret) {
      return res.status(500).json({
        status: 'failed',
        error: 'Server configuration error: RAZORPAY_KEY_SECRET is missing.',
      });
    }

    const body = `${razorpay_order_id}|${razorpay_payment_id}`;
    const generatedSignature = crypto
      .createHmac('sha256', key_secret)
      .update(body.toString())
      .digest('hex');

    if (generatedSignature === razorpay_signature) {
      return res.status(200).json({
        status: 'success',
        verified: true,
        message: 'Payment signature verified successfully',
        payment_id: razorpay_payment_id,
        order_id: razorpay_order_id,
      });
    } else {
      return res.status(400).json({
        status: 'failed',
        verified: false,
        error: 'Payment verification failed: Signature mismatch',
      });
    }
  } catch (error: any) {
    console.error('Razorpay signature verification error:', error);
    return res.status(500).json({
      status: 'failed',
      error: error?.message || 'Internal server error during signature verification',
    });
  }
});

// --------------------------------------------------------------------------
// Callback endpoint for Razorpay Redirect Flows (UPI apps, NetBanking, 3DS, Payment Links)
// Endpoint: POST & GET /api/payment-callback
// --------------------------------------------------------------------------
app.all(['/api/payment-callback', '/api/razorpay/callback'], async (req, res) => {
  try {
    const payload = req.method === 'POST' ? req.body : req.query;
    const razorpay_order_id = payload.razorpay_order_id;
    const razorpay_payment_id = payload.razorpay_payment_id;
    const razorpay_signature = payload.razorpay_signature;
    const razorpay_payment_link_id = payload.razorpay_payment_link_id;
    const razorpay_payment_link_status = payload.razorpay_payment_link_status;
    const error_code = payload.error_code || payload['error[code]'];
    const error_desc = payload.error_description || payload['error[description]'];

    if (error_code || error_desc) {
      console.warn('Razorpay callback received error:', error_code, error_desc);
      return res.redirect(`/?payment_status=failed&error=${encodeURIComponent(error_desc || error_code || 'Payment failed')}`);
    }

    // 1. Handle Payment Link Callback (rzp.io redirect)
    if (razorpay_payment_link_id && razorpay_payment_id) {
      try {
        const razorpay = getRazorpayClient();
        const payment = await razorpay.payments.fetch(razorpay_payment_id);
        if (payment.status === 'captured' || payment.status === 'authorized' || razorpay_payment_link_status === 'paid') {
          console.log('Razorpay payment link callback verified:', razorpay_payment_id);
          return res.redirect(
            `/?payment_status=success&payment_id=${encodeURIComponent(razorpay_payment_id)}&order_id=${encodeURIComponent(razorpay_payment_link_id)}&link_paid=true`
          );
        } else {
          return res.redirect(`/?payment_status=failed&error=${encodeURIComponent((payment as any).error_description || 'Payment not captured')}`);
        }
      } catch (linkErr: any) {
        console.error('Error verifying payment link callback:', linkErr);
      }
    }

    // 2. Handle Standard Order Callback
    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      return res.redirect('/?payment_status=failed&error=missing_parameters');
    }

    const key_secret = process.env.RAZORPAY_KEY_SECRET;
    if (!key_secret) {
      return res.redirect('/?payment_status=failed&error=server_configuration_error');
    }

    const body = `${razorpay_order_id}|${razorpay_payment_id}`;
    const generatedSignature = crypto
      .createHmac('sha256', key_secret)
      .update(body.toString())
      .digest('hex');

    if (generatedSignature === razorpay_signature) {
      console.log('Razorpay callback payment verified:', razorpay_payment_id);
      return res.redirect(
        `/?payment_status=success&payment_id=${encodeURIComponent(razorpay_payment_id)}&order_id=${encodeURIComponent(razorpay_order_id)}&signature=${encodeURIComponent(razorpay_signature)}`
      );
    } else {
      console.warn('Razorpay callback signature mismatch');
      return res.redirect('/?payment_status=failed&error=signature_mismatch');
    }
  } catch (err: any) {
    console.error('Error in /api/payment-callback:', err);
    return res.redirect(`/?payment_status=failed&error=${encodeURIComponent(err.message || 'unknown_error')}`);
  }
});

// Endpoint to create a Razorpay Hosted Payment Link (hosted on rzp.io - bypasses website domain restrictions)
app.post(['/api/create-payment-link', '/api/razorpay/create-payment-link'], async (req, res) => {
  try {
    const { amount, currency = 'INR', customer, description, notes } = req.body;
    const parsedAmount = Math.round(Number(amount));
    if (isNaN(parsedAmount) || parsedAmount < 100) {
      return res.status(400).json({ error: 'Minimum amount is 100 paise (₹1.00)' });
    }

    const host = req.get('host');
    const protocol = req.protocol === 'https' || req.headers['x-forwarded-proto'] === 'https' ? 'https' : 'http';
    const baseUrl = `${protocol}://${host}`;

    const razorpay = getRazorpayClient();
    const link = await razorpay.paymentLink.create({
      amount: parsedAmount,
      currency: currency || 'INR',
      accept_partial: false,
      description: description || 'SuperCart Grocery Order',
      customer: {
        name: customer?.name || 'Valued Shopper',
        email: customer?.email || 'customer@supercart.com',
        contact: customer?.phone || '+919876543210',
      },
      callback_url: `${baseUrl}/api/payment-callback`,
      callback_method: 'get',
      notes: notes || {},
    });

    return res.status(200).json({
      link_id: link.id,
      url: link.short_url,
      amount: link.amount,
      status: link.status,
    });
  } catch (error: any) {
    console.error('Error creating payment link:', error);
    return res.status(500).json({ error: error?.message || 'Failed to create payment link' });
  }
});

// Endpoint to fetch real-time Razorpay payment status
app.get('/api/check-payment/:paymentId', async (req, res) => {
  try {
    const { paymentId } = req.params;
    const razorpay = getRazorpayClient();
    const payment = await razorpay.payments.fetch(paymentId);
    return res.json({
      id: payment.id,
      status: payment.status, // 'captured' | 'authorized' | 'failed' | 'refunded'
      amount: payment.amount,
      currency: payment.currency,
      order_id: payment.order_id,
      method: payment.method,
      error_code: (payment as any).error_code || null,
      error_description: (payment as any).error_description || null,
      error_reason: (payment as any).error_reason || null,
    });
  } catch (error: any) {
    return res.status(500).json({ error: error?.message || 'Failed to fetch payment' });
  }
});

// Endpoint to fetch latest payment on merchant account
app.get('/api/latest-payment-status', async (req, res) => {
  try {
    const razorpay = getRazorpayClient();
    const payments = await razorpay.payments.all({ count: 1 });
    if (!payments.items || payments.items.length === 0) {
      return res.json({ found: false });
    }
    const latest = payments.items[0];
    return res.json({
      found: true,
      id: latest.id,
      order_id: latest.order_id,
      amount: latest.amount,
      status: latest.status,
      method: latest.method,
      error_code: (latest as any).error_code || null,
      error_description: (latest as any).error_description || null,
      error_reason: (latest as any).error_reason || null,
      created_at: latest.created_at,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err?.message || 'Failed to fetch latest payment' });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    razorpayConfigured: Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET),
  });
});

async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`> SuperCart server running at http://0.0.0.0:${port}`);
  });
}

startServer();
